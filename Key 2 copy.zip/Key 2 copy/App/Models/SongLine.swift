struct SongLine: Codable, Hashable, Identifiable {
  var lyric: String
  var chords: [TimedChord]

  var id: String {
    "\(lyric)-\(chords.map(\.id).joined(separator: "-"))"
  }

  func shifted(by semitones: Int) -> SongLine {
    SongLine(
      lyric: lyric,
      chords: chords.map { $0.shifted(by: semitones) }
    )
  }
}
