import SwiftUI

struct ChordCarouselPane: View {
  var song: Song
  @Bindable var playback: PlaybackState

  private var chords: [Chord] { song.uniqueChords }

  var body: some View {
    GeometryReader { geometry in
      let compact = geometry.size.height < 430
      let strumHeight: CGFloat = compact ? 78 : 105
      let cardHeight = min(326, max(160, geometry.size.height - strumHeight - (compact ? 88 : 104)))
      let currentCardWidth = min(240, max(174, geometry.size.width * 0.43))
      let neighborCardWidth = min(170, max(126, geometry.size.width * 0.31))

      VStack(spacing: compact ? 7 : 11) {
        header
          .padding(.horizontal, 18)

        if chords.isEmpty {
          ContentUnavailableView("No chords", systemImage: "music.note")
        } else {
          ScrollViewReader { scrollProxy in
            ScrollView(.horizontal) {
              HStack(alignment: .center, spacing: compact ? 10 : 14) {
                ForEach(Array(chords.enumerated()), id: \.element.id) { index, chord in
                  let activeIndex = playback.currentChordCarouselIndex
                  let isCurrent = activeIndex == index
                  let distance = abs((activeIndex ?? index) - index)
                  let width = isCurrent ? currentCardWidth : neighborCardWidth
                  ChordCardView(
                    chord: chord,
                    isCurrent: isCurrent,
                    diagramHeight: max(66, cardHeight - (isCurrent ? 100 : 82))
                  )
                  .frame(width: width, height: cardHeight)
                  .scaleEffect(isCurrent ? 1 : (distance == 1 ? 0.96 : 0.91))
                  .opacity(isCurrent ? 1 : (distance == 1 ? 0.72 : 0.48))
                  .id(chord.id)
                  .animation(.easeInOut(duration: 0.3), value: activeIndex)
                }
              }
              .padding(.horizontal, max(18, geometry.size.width * 0.09))
              .frame(height: cardHeight)
            }
            .frame(height: cardHeight)
            .scrollIndicators(.hidden)
            .scrollBounceBehavior(.basedOnSize, axes: .horizontal)
            .onChange(of: playback.currentChordCarouselIndex) { _, index in
              guard let index, chords.indices.contains(index) else { return }
              withAnimation(.easeInOut(duration: 0.34)) {
                scrollProxy.scrollTo(chords[index].id, anchor: .center)
              }
            }
            .onAppear {
              if let index = playback.currentChordCarouselIndex, chords.indices.contains(index) {
                scrollProxy.scrollTo(chords[index].id, anchor: .center)
              }
            }
          }
        }

        if let section = playback.currentSection {
          StrumPatternView(
            sectionName: section.name,
            pattern: section.strumPattern,
            technique: section.technique,
            currentBeat: playback.currentBeat,
            isPlaying: playback.isPlaying,
            accent: playback.currentChord?.root.color(for: playback.currentChord?.quality ?? .major) ?? Color(hex: "#3B5BDB"),
            compact: compact
          )
          .padding(.horizontal, compact ? 14 : 18)
        }
      }
      .padding(.vertical, compact ? 7 : 12)
      .frame(maxWidth: .infinity, maxHeight: .infinity)
    }
  }

  private var header: some View {
    HStack {
      Text("CHORDS")
        .font(.system(size: 14, weight: .bold, design: .rounded))
        .tracking(1.1)
        .foregroundStyle(Color(hex: "#77738A"))

      Spacer()

      Text("Key of \(song.key.displayName) · \(playback.transposeSemitones == 0 ? "Original" : "Transposed")")
        .font(.system(size: 12, weight: .semibold, design: .rounded))
        .foregroundStyle(Color(hex: "#59556D"))
        .padding(.horizontal, 12)
        .padding(.vertical, 7)
        .background(Color(hex: "#E7E8F0").opacity(0.82), in: Capsule())
    }
    .frame(height: 26)
  }
}
