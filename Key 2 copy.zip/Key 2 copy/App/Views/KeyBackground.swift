import SwiftUI

struct KeyBackground: View {
  private let stars: [(x: CGFloat, y: CGFloat, size: CGFloat, opacity: Double)] = [
    (0.06, 0.12, 2, 0.36), (0.19, 0.08, 1.5, 0.28), (0.33, 0.17, 1.2, 0.42),
    (0.48, 0.06, 1.5, 0.3), (0.65, 0.14, 1.8, 0.38), (0.82, 0.08, 1.2, 0.3),
    (0.94, 0.19, 1.5, 0.34), (0.12, 0.34, 1.2, 0.24), (0.28, 0.29, 1.6, 0.34),
    (0.72, 0.32, 1.3, 0.27), (0.88, 0.42, 1.7, 0.35), (0.08, 0.57, 1.7, 0.34),
    (0.37, 0.49, 1.2, 0.25), (0.57, 0.61, 1.5, 0.32), (0.77, 0.55, 1.2, 0.26),
    (0.95, 0.68, 1.7, 0.36), (0.18, 0.78, 1.4, 0.3), (0.42, 0.87, 1.8, 0.33),
    (0.63, 0.79, 1.2, 0.26), (0.84, 0.91, 1.5, 0.32), (0.29, 0.96, 1.2, 0.22)
  ]

  var body: some View {
    GeometryReader { proxy in
      ZStack {
        Color(hex: "#FBFAFE")
        RadialGradient(
          colors: [Color(hex: "#E8DFFD").opacity(0.42), .clear],
          center: .topLeading,
          startRadius: 0,
          endRadius: proxy.size.width * 0.82
        )
        RadialGradient(
          colors: [Color(hex: "#FFE6DA").opacity(0.36), .clear],
          center: .topTrailing,
          startRadius: 0,
          endRadius: proxy.size.width * 0.72
        )
        RadialGradient(
          colors: [Color(hex: "#DDF1FF").opacity(0.38), .clear],
          center: .bottomLeading,
          startRadius: 0,
          endRadius: proxy.size.width * 0.78
        )
        Canvas { context, size in
          for star in stars {
            let rect = CGRect(
              x: size.width * star.x,
              y: size.height * star.y,
              width: star.size,
              height: star.size
            )
            context.fill(Path(ellipseIn: rect), with: .color(.white.opacity(star.opacity)))
          }
        }
      }
      .ignoresSafeArea()
    }
    .accessibilityHidden(true)
  }
}
