import AVFoundation
import Observation

@MainActor
@Observable
final class CameraCaptureModel {
  private let controller: CameraCaptureSessionController

  var isSessionReady = false
  var isPreparingRecording = false
  var isRecording = false
  var errorMessage: String?
  var lastRecordingURL: URL?

  var session: AVCaptureSession {
    controller.session
  }

  init() {
    let controller = CameraCaptureSessionController()
    self.controller = controller
    controller.setRecordingFinishedHandler { [weak self] fileURL, errorMessage in
      guard let self else { return }
      isPreparingRecording = false
      isRecording = false
      if let errorMessage {
        self.errorMessage = errorMessage
      } else {
        lastRecordingURL = fileURL
      }
    }
  }

  func prepareSession() {
    Task {
      guard await requestAccess(for: .video) else {
        errorMessage = "Allow camera access in Settings to record a practice video."
        return
      }

      controller.startSession { [weak self] errorMessage in
        guard let self else { return }
        self.errorMessage = errorMessage
        isSessionReady = errorMessage == nil
      }
    }
  }

  func toggleRecording() {
    if isRecording {
      stopRecording()
    } else {
      startRecording()
    }
  }

  func startRecording() {
    guard isSessionReady, !isRecording, !isPreparingRecording else { return }
    lastRecordingURL = nil
    errorMessage = nil
    isPreparingRecording = true

    Task {
      let hasAudioAccess = await requestAccess(for: .audio)
      guard isSessionReady, isPreparingRecording else { return }
      controller.startRecording(captureAudio: hasAudioAccess) { [weak self] didStart in
        guard let self else { return }
        isPreparingRecording = false
        isRecording = didStart
        if !didStart {
          errorMessage = "Recording could not start. Try again."
        }
      }
    }
  }

  func stopRecording() {
    controller.stopRecording()
  }

  func stopSession() {
    isSessionReady = false
    isPreparingRecording = false
    controller.stopSession()
  }

  private func requestAccess(for mediaType: AVMediaType) async -> Bool {
    switch AVCaptureDevice.authorizationStatus(for: mediaType) {
    case .authorized:
      return true
    case .notDetermined:
      return await withCheckedContinuation { continuation in
        AVCaptureDevice.requestAccess(for: mediaType) { granted in
          continuation.resume(returning: granted)
        }
      }
    case .denied, .restricted:
      return false
    @unknown default:
      return false
    }
  }
}

private final class CameraCaptureSessionController: NSObject, AVCaptureFileOutputRecordingDelegate, @unchecked Sendable {
  let session = AVCaptureSession()

  private let movieOutput = AVCaptureMovieFileOutput()
  private let sessionQueue = DispatchQueue(label: "app.key.camera-capture")
  private var hasConfiguredAudioInput = false
  private var hasConfiguredSession = false
  private var shouldStopSessionWhenRecordingFinishes = false
  private var recordingFinishedHandler: (@MainActor @Sendable (URL?, String?) -> Void)?

  func setRecordingFinishedHandler(
    _ handler: @escaping @MainActor @Sendable (URL?, String?) -> Void
  ) {
    sessionQueue.async { [weak self] in
      self?.recordingFinishedHandler = handler
    }
  }

  func startSession(completion: @escaping @MainActor @Sendable (String?) -> Void) {
    sessionQueue.async { [weak self] in
      guard let self else { return }
      shouldStopSessionWhenRecordingFinishes = false

      do {
        try configureSessionIfNeeded()
        if !session.isRunning {
          session.startRunning()
        }
        Task { @MainActor in completion(nil) }
      } catch {
        let message = error.localizedDescription
        Task { @MainActor in completion(message) }
      }
    }
  }

  func startRecording(
    captureAudio: Bool,
    completion: @escaping @MainActor @Sendable (Bool) -> Void
  ) {
    sessionQueue.async { [weak self] in
      guard let self, session.isRunning, !movieOutput.isRecording else {
        Task { @MainActor in completion(false) }
        return
      }

      configureAudioInputIfNeeded(enabled: captureAudio)
      let fileURL = FileManager.default.temporaryDirectory
        .appendingPathComponent(UUID().uuidString)
        .appendingPathExtension("mov")
      movieOutput.startRecording(to: fileURL, recordingDelegate: self)
      let didStart = movieOutput.isRecording
      Task { @MainActor in completion(didStart) }
    }
  }

  func stopRecording() {
    sessionQueue.async { [weak self] in
      guard let self, movieOutput.isRecording else { return }
      movieOutput.stopRecording()
    }
  }

  func stopSession() {
    sessionQueue.async { [weak self] in
      guard let self else { return }
      shouldStopSessionWhenRecordingFinishes = true

      if movieOutput.isRecording {
        movieOutput.stopRecording()
      } else {
        stopSessionAfterRecording()
      }
    }
  }

  func fileOutput(
    _ output: AVCaptureFileOutput,
    didFinishRecordingTo outputFileURL: URL,
    from connections: [AVCaptureConnection],
    error: Error?
  ) {
    let errorMessage = error?.localizedDescription
    sessionQueue.async { [weak self] in
      guard let self else { return }
      let handler = recordingFinishedHandler
      if shouldStopSessionWhenRecordingFinishes {
        stopSessionAfterRecording()
      }
      Task { @MainActor in handler?(outputFileURL, errorMessage) }
    }
  }

  private func configureSessionIfNeeded() throws {
    guard !hasConfiguredSession else { return }

    session.beginConfiguration()
    defer { session.commitConfiguration() }

    session.sessionPreset = .high

    guard let camera = AVCaptureDevice.default(.builtInWideAngleCamera, for: .video, position: .front) else {
      throw CameraCaptureError.frontCameraUnavailable
    }
    let cameraInput = try AVCaptureDeviceInput(device: camera)
    guard session.canAddInput(cameraInput) else {
      throw CameraCaptureError.cannotAddCameraInput
    }
    session.addInput(cameraInput)

    guard session.canAddOutput(movieOutput) else {
      throw CameraCaptureError.cannotAddMovieOutput
    }
    session.addOutput(movieOutput)
    hasConfiguredSession = true
  }

  private func configureAudioInputIfNeeded(enabled: Bool) {
    guard enabled, !hasConfiguredAudioInput,
          let microphone = AVCaptureDevice.default(for: .audio),
          let microphoneInput = try? AVCaptureDeviceInput(device: microphone),
          session.canAddInput(microphoneInput) else { return }

    session.beginConfiguration()
    session.addInput(microphoneInput)
    session.commitConfiguration()
    hasConfiguredAudioInput = true
  }

  private func stopSessionAfterRecording() {
    if session.isRunning {
      session.stopRunning()
    }
  }
}

private enum CameraCaptureError: LocalizedError {
  case frontCameraUnavailable
  case cannotAddCameraInput
  case cannotAddMovieOutput

  var errorDescription: String? {
    switch self {
    case .frontCameraUnavailable:
      "The front camera is unavailable on this device."
    case .cannotAddCameraInput:
      "The camera could not be added to the capture session."
    case .cannotAddMovieOutput:
      "Video recording is unavailable right now."
    }
  }
}
