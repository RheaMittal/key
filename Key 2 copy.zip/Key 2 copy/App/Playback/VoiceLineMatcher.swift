import Foundation

struct SongLinePosition: Hashable {
  var sectionIndex: Int
  var lineIndex: Int
}

enum VoiceLineMatcher {
  private struct Match {
    var position: SongLinePosition
    var offset: Int
    var score: Double
  }

  private static let ignoredWords: Set<String> = [
    "a", "an", "and", "are", "as", "at", "be", "been", "but", "by",
    "do", "does", "did", "for", "from", "he", "her", "him", "his",
    "i", "if", "in", "is", "it", "its", "me", "my", "of", "on", "or",
    "our", "she", "so", "that", "the", "them", "they", "this", "to",
    "us", "was", "we", "were", "what", "when", "where", "which", "who",
    "will", "with", "you", "your"
  ]

  static func forwardCorrection(
    transcript: String,
    in song: Song,
    currentSectionIndex: Int,
    currentLineIndex: Int
  ) -> SongLinePosition? {
    forwardCorrection(
      transcripts: [transcript],
      in: song,
      currentSectionIndex: currentSectionIndex,
      currentLineIndex: currentLineIndex
    )
  }

  static func forwardCorrection(
    transcripts: [String],
    in song: Song,
    currentSectionIndex: Int,
    currentLineIndex: Int
  ) -> SongLinePosition? {
    let lines = song.sections.enumerated().flatMap { sectionIndex, section in
      section.lines.enumerated().map { lineIndex, line in
        (position: SongLinePosition(sectionIndex: sectionIndex, lineIndex: lineIndex), line: line)
      }
    }

    guard let currentOffset = lines.firstIndex(where: {
      $0.position.sectionIndex == currentSectionIndex && $0.position.lineIndex == currentLineIndex
    }) else {
      return nil
    }

    let recognizedVariants = transcripts.map { transcript in
      Array(words(in: transcript).suffix(36))
    }.filter { !$0.isEmpty }
    guard !recognizedVariants.isEmpty else { return nil }

    let candidates = lines.enumerated()
      .dropFirst(currentOffset + 1)
      .prefix(12)

    let matches = candidates.compactMap { offset, candidate -> Match? in
      let lyricWords = words(in: candidate.line.lyric)
        .filter { !ignoredWords.contains($0) }
        .uniqued()
      guard !lyricWords.isEmpty else { return nil }

      let matchedCount = recognizedVariants
        .map { orderedMatchCount(lyricWords, in: $0) }
        .max() ?? 0
      let requiredMatches = min(2, lyricWords.count)
      guard matchedCount >= requiredMatches else { return nil }

      let denominator = Double(min(lyricWords.count, 5))
      let coverage = Double(matchedCount) / denominator
      return Match(position: candidate.position, offset: offset, score: coverage)
    }

    return matches.sorted {
      if $0.score != $1.score { return $0.score > $1.score }
      return $0.offset < $1.offset
    }.first?.position
  }

  static func words(in text: String) -> [String] {
    var normalized = text
      .lowercased(with: Locale(identifier: "en_US_POSIX"))
      .replacingOccurrences(of: "’", with: "'")

    let contractions = [
      "can't": "can not", "won't": "will not", "shan't": "shall not",
      "don't": "do not", "doesn't": "does not", "didn't": "did not",
      "couldn't": "could not", "wouldn't": "would not", "shouldn't": "should not",
      "weren't": "were not", "wasn't": "was not", "isn't": "is not",
      "aren't": "are not", "haven't": "have not", "hasn't": "has not",
      "hadn't": "had not", "i'm": "i am", "you're": "you are",
      "we're": "we are", "they're": "they are", "it's": "it is",
      "that's": "that is", "i've": "i have", "you've": "you have",
      "we've": "we have", "i'll": "i will", "you'll": "you will",
      "we'll": "we will", "they'll": "they will", "'cause": "cause"
    ]

    for (contraction, expansion) in contractions {
      normalized = normalized.replacingOccurrences(of: contraction, with: expansion)
    }
    normalized = normalized.replacingOccurrences(
      of: #"'s\b"#,
      with: "s",
      options: .regularExpression
    )

    return normalized
      .split(whereSeparator: { !$0.isLetter && !$0.isNumber })
      .map { canonicalWord(String($0)) }
      .filter { !$0.isEmpty }
  }

  private static func orderedMatchCount(_ expected: [String], in recognized: [String]) -> Int {
    var matchedCount = 0
    var nextRecognizedIndex = 0

    for word in expected {
      guard nextRecognizedIndex < recognized.count else { break }
      for index in nextRecognizedIndex..<recognized.count where recognized[index] == word {
        matchedCount += 1
        nextRecognizedIndex = index + 1
        break
      }
    }

    return matchedCount
  }

  private static func canonicalWord(_ word: String) -> String {
    switch word {
    case "drove", "drives", "driving":
      return "drive"
    case "talked", "talking", "talks":
      return "talk"
    case "sang", "sung", "singing", "sings":
      return "sing"
    case "excited", "excites", "exciting":
      return "excite"
    default:
      if word.count > 5, word.hasSuffix("ing") {
        return String(word.dropLast(3))
      }
      if word.count > 4, word.hasSuffix("ed") {
        return String(word.dropLast(2))
      }
      if word.count > 4, word.hasSuffix("s") {
        return String(word.dropLast())
      }
      return word
    }
  }
}

private extension Array where Element: Hashable {
  func uniqued() -> [Element] {
    var seen: Set<Element> = []
    return filter { seen.insert($0).inserted }
  }
}
