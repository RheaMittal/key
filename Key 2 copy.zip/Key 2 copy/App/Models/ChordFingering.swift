struct ChordFingering: Hashable, Identifiable {
  var chord: Chord
  var frets: [Int]

  var id: String { chord.symbol }

  init(_ symbol: String, _ frets: String) {
    chord = Chord(symbol: symbol) ?? Chord(root: .c)
    self.frets = frets.map { $0.lowercased() == "x" ? -1 : (Int(String($0)) ?? -1) }
  }

  init(_ symbol: String, _ frets: [Int]) {
    chord = Chord(symbol: symbol) ?? Chord(root: .c)
    self.frets = frets
  }

  init(chord: Chord, frets: [Int]) {
    self.chord = chord
    self.frets = frets
  }
}
