struct EasyKeySuggestion: Hashable {
  var semitones: Int
  var score: Double
  var song: Song
}
