import AVFoundation
import Foundation
import Observation
import Speech

@MainActor @Observable
final class VoiceFollowingService {
  private(set) var isEnabled = false
  private(set) var isListening = false
  private(set) var statusMessage: String?
  private(set) var latestTranscript: String?

  var controlTitle: String {
    guard isListening else { return "Follow my voice" }
    let recentWords = VoiceLineMatcher.words(in: latestTranscript ?? "").suffix(3)
    guard !recentWords.isEmpty else { return "Listening" }
    return "Heard: \(recentWords.joined(separator: " "))"
  }

  @ObservationIgnored private weak var playback: PlaybackState?
  @ObservationIgnored private var generation = 0
  @ObservationIgnored private var backend: Backend?
  @ObservationIgnored private var speechAnalyzer: SpeechAnalyzer?
  @ObservationIgnored private var speechTranscriber: SpeechTranscriber?
  @ObservationIgnored private var captureProvider: CaptureInputSequenceProvider?
  @ObservationIgnored private var resultsTask: Task<Void, Never>?
  @ObservationIgnored private var legacyEngine: AVAudioEngine?
  @ObservationIgnored private var legacyRecognizer: SFSpeechRecognizer?
  @ObservationIgnored private var legacyRequest: SFSpeechAudioBufferRecognitionRequest?
  @ObservationIgnored private var legacyRecognitionTask: SFSpeechRecognitionTask?
  @ObservationIgnored private var legacyBufferSink: LegacyAudioBufferSink?
  @ObservationIgnored private var legacyRotationTask: Task<Void, Never>?
  @ObservationIgnored private var silenceMonitorTask: Task<Void, Never>?
  @ObservationIgnored private var lastSpeechAt = Date.now
  @ObservationIgnored private var hasPausedForSilence = false
  @ObservationIgnored private var lastTranscriptSignature = ""
  @ObservationIgnored private var lastTranscriptAt = Date.distantPast

  func setEnabled(_ enabled: Bool, playback: PlaybackState) async {
    guard enabled else {
      await stop()
      return
    }
    guard !isEnabled else { return }

    generation += 1
    let requestGeneration = generation
    self.playback = playback
    isEnabled = true
    isListening = false
    statusMessage = nil
    latestTranscript = nil
    lastTranscriptSignature = ""
    playback.setVoiceFollowingActive(true)

    guard await requestMicrophonePermission() else {
      await fail("Microphone access is off. Allow it in Settings to follow the lyrics.", generation: requestGeneration)
      return
    }
    guard isCurrent(requestGeneration) else { return }

    guard await requestSpeechPermission() else {
      await fail("Speech Recognition access is off. Allow it in Settings to follow the lyrics.", generation: requestGeneration)
      return
    }
    guard isCurrent(requestGeneration) else { return }

    do {
      try await startSpeechAnalyzer(generation: requestGeneration)
    } catch {
      await stopBackends()
      guard isCurrent(requestGeneration) else { return }

      do {
        try startOnDeviceFallback(generation: requestGeneration)
      } catch {
        await fail(
          "On-device speech recognition isn’t available for English on this device.",
          generation: requestGeneration
        )
      }
    }
  }

  func stop() async {
    generation += 1
    isEnabled = false
    isListening = false
    statusMessage = nil
    latestTranscript = nil
    silenceMonitorTask?.cancel()
    silenceMonitorTask = nil
    legacyRotationTask?.cancel()
    legacyRotationTask = nil
    await stopBackends()
    playback?.setVoiceFollowingActive(false)
    playback = nil
    hasPausedForSilence = false
    lastTranscriptSignature = ""
    try? AVAudioSession.sharedInstance().setActive(false, options: .notifyOthersOnDeactivation)
  }

  func dismissStatusMessage() {
    statusMessage = nil
  }

  private func startSpeechAnalyzer(generation requestGeneration: Int) async throws {
    guard SpeechTranscriber.isAvailable,
          let locale = await SpeechTranscriber.supportedLocale(equivalentTo: Locale(identifier: "en-US")) else {
      throw VoiceFollowingError.localTranscriptionUnavailable
    }

    let progressivePreset = SpeechTranscriber.Preset.progressiveTranscription
    let transcriber = SpeechTranscriber(
      locale: locale,
      transcriptionOptions: progressivePreset.transcriptionOptions,
      reportingOptions: progressivePreset.reportingOptions.union([.alternativeTranscriptions]),
      attributeOptions: progressivePreset.attributeOptions
    )
    let modules: [any SpeechModule] = [transcriber]
    guard await AssetInventory.status(forModules: modules) == .installed else {
      throw VoiceFollowingError.localTranscriptionUnavailable
    }
    guard let microphone = AVCaptureDevice.default(for: .audio) else {
      throw VoiceFollowingError.microphoneUnavailable
    }

    let provider = try await CaptureInputSequenceProvider.providerWithSession(
      from: microphone,
      compatibleWith: modules,
      priority: .userInitiated
    )
    guard isCurrent(requestGeneration) else {
      provider.captureSession.stopRunning()
      throw CancellationError()
    }

    let analyzer = SpeechAnalyzer(modules: modules)
    let audioFormat = await SpeechAnalyzer.bestAvailableAudioFormat(compatibleWith: modules)
    try await analyzer.prepareToAnalyze(in: audioFormat)
    guard isCurrent(requestGeneration) else {
      provider.captureSession.stopRunning()
      throw CancellationError()
    }

    self.captureProvider = provider
    speechAnalyzer = analyzer
    speechTranscriber = transcriber
    backend = .speechAnalyzer

    resultsTask = Task { [weak self] in
      do {
        for try await result in transcriber.results {
          guard !Task.isCancelled else { return }
          self?.receiveTranscript(
            String(result.text.characters),
            alternatives: result.alternatives.map { String($0.characters) }
          )
        }
        self?.handleRecognitionStreamEnd(generation: requestGeneration)
      } catch {
        self?.handleRecognitionStreamEnd(error: error, generation: requestGeneration)
      }
    }

    provider.captureSession.startRunning()
    try await analyzer.start(inputSequence: provider.analyzerInputs)
    guard isCurrent(requestGeneration) else {
      await stopBackends()
      return
    }
    beginListening()
  }

  private func startOnDeviceFallback(generation requestGeneration: Int) throws {
    guard let recognizer = SFSpeechRecognizer(locale: Locale(identifier: "en-US")),
          recognizer.isAvailable,
          recognizer.supportsOnDeviceRecognition else {
      throw VoiceFollowingError.localTranscriptionUnavailable
    }

    let audioSession = AVAudioSession.sharedInstance()
    try audioSession.setCategory(.record, mode: .measurement, options: [])
    try audioSession.setActive(true)
    try startLegacyRecognition(using: recognizer, generation: requestGeneration)
  }

  private func startLegacyRecognition(using recognizer: SFSpeechRecognizer, generation requestGeneration: Int) throws {
      guard isCurrent(requestGeneration) else { return }

    let request = SFSpeechAudioBufferRecognitionRequest()
    request.shouldReportPartialResults = true
    request.requiresOnDeviceRecognition = true

    let audioEngine = AVAudioEngine()
    let audioSink = LegacyAudioBufferSink()
    audioSink.setRequest(request)

    do {
      try audioEngine.inputNode.installAudioTap(onBus: 0, bufferSize: 2048, format: nil) { buffer, _ in
        audioSink.append(buffer)
      }
      audioEngine.prepare()

      let task = recognizer.recognitionTask(with: request) { [weak self] result, error in
        if let transcript = result?.bestTranscription.formattedString {
          Task { @MainActor [weak self] in
            self?.receiveTranscript(transcript)
          }
        }

        if result?.isFinal == true {
          Task { @MainActor [weak self] in
            await self?.restartLegacyRecognition(generation: requestGeneration)
          }
        } else if let error {
          Task { @MainActor [weak self] in
            self?.handleRecognitionStreamEnd(error: error, generation: requestGeneration)
          }
        }
      }

      legacyRecognizer = recognizer
      legacyRequest = request
      legacyRecognitionTask = task
      legacyBufferSink = audioSink
      legacyEngine = audioEngine
      backend = .legacy
      try audioEngine.start()
      beginListening()
      scheduleLegacyRotation(generation: requestGeneration)
    } catch {
      audioSink.setRequest(nil)
      audioEngine.inputNode.removeTap(onBus: 0)
      audioEngine.stop()
      legacyEngine = nil
      legacyRecognizer = nil
      legacyRequest = nil
      legacyRecognitionTask = nil
      legacyBufferSink = nil
      backend = nil
      throw error
    }
  }

  private func restartLegacyRecognition(generation requestGeneration: Int) async {
    guard isCurrent(requestGeneration), backend == .legacy,
          let recognizer = legacyRecognizer else { return }
    legacyRotationTask?.cancel()
    legacyRotationTask = nil
    stopLegacyBackend()
    do {
      try startLegacyRecognition(using: recognizer, generation: requestGeneration)
    } catch {
      await fail("On-device speech recognition stopped. Try turning voice following on again.", generation: requestGeneration)
    }
  }

  private func scheduleLegacyRotation(generation requestGeneration: Int) {
    legacyRotationTask?.cancel()
    legacyRotationTask = Task { [weak self] in
      try? await Task.sleep(for: .seconds(50))
      guard !Task.isCancelled else { return }
      await self?.restartLegacyRecognition(generation: requestGeneration)
    }
  }

  private func receiveTranscript(_ transcript: String, alternatives: [String] = []) {
    let transcriptWords = VoiceLineMatcher.words(in: transcript)
    guard !transcriptWords.isEmpty else { return }

    latestTranscript = transcript
    lastSpeechAt = .now
    if hasPausedForSilence {
      hasPausedForSilence = false
    }
    if let playback, !playback.isPlaying {
      playback.start()
    }

    let signature = ([transcript] + alternatives)
      .map { VoiceLineMatcher.words(in: $0).suffix(36).joined(separator: " ") }
      .joined(separator: "|")
    guard signature != lastTranscriptSignature || Date.now.timeIntervalSince(lastTranscriptAt) > 1.5 else { return }
    lastTranscriptSignature = signature
    lastTranscriptAt = .now

    guard let playback, let song = playback.song,
          let position = VoiceLineMatcher.forwardCorrection(
            transcripts: [transcript] + alternatives,
            in: song,
            currentSectionIndex: playback.currentSectionIndex,
            currentLineIndex: playback.currentLineIndex
          ) else {
      return
    }
    playback.correctForward(to: position)
  }

  private func handleRecognitionStreamEnd(error: Error? = nil, generation requestGeneration: Int) {
    guard isCurrent(requestGeneration) else { return }
    let message = error.map {
      "Speech recognition stopped: \($0.localizedDescription)"
    } ?? "Speech recognition stopped unexpectedly. Turn voice following off and on to retry."
    Task { @MainActor in
      await fail(message, generation: requestGeneration)
    }
  }

  private func beginListening() {
    isListening = true
    lastSpeechAt = .now
    hasPausedForSilence = false
    silenceMonitorTask?.cancel()
    silenceMonitorTask = Task { [weak self] in
      while !Task.isCancelled {
        try? await Task.sleep(for: .milliseconds(250))
        guard let self, self.isEnabled, self.isListening else { return }
        guard !self.hasPausedForSilence,
              Date.now.timeIntervalSince(self.lastSpeechAt) >= 3 else { continue }
        self.playback?.stop()
        self.hasPausedForSilence = true
      }
    }
  }

  private func requestMicrophonePermission() async -> Bool {
    await withCheckedContinuation { continuation in
      AVAudioApplication.requestRecordPermission { granted in
        continuation.resume(returning: granted)
      }
    }
  }

  private func requestSpeechPermission() async -> Bool {
    if SFSpeechRecognizer.authorizationStatus() == .authorized { return true }
    return await withCheckedContinuation { continuation in
      SFSpeechRecognizer.requestAuthorization { status in
        continuation.resume(returning: status == .authorized)
      }
    }
  }

  private func fail(_ message: String, generation requestGeneration: Int) async {
    guard isCurrent(requestGeneration) else { return }
    await stop()
    statusMessage = message
  }

  private func stopBackends() async {
    resultsTask?.cancel()
    resultsTask = nil
    if let captureProvider {
      captureProvider.captureSession.stopRunning()
    }
    if let speechAnalyzer {
      await speechAnalyzer.cancelAndFinishNow()
    }
    captureProvider = nil
    speechAnalyzer = nil
    speechTranscriber = nil
    stopLegacyBackend()
    backend = nil
  }

  private func stopLegacyBackend() {
    legacyRotationTask?.cancel()
    legacyRotationTask = nil
    legacyBufferSink?.setRequest(nil)
    legacyRequest?.endAudio()
    legacyRecognitionTask?.cancel()
    if let legacyEngine {
      legacyEngine.inputNode.removeTap(onBus: 0)
      legacyEngine.stop()
    }
    legacyEngine = nil
    legacyRecognizer = nil
    legacyRequest = nil
    legacyRecognitionTask = nil
    legacyBufferSink = nil
  }

  private func isCurrent(_ requestGeneration: Int) -> Bool {
    isEnabled && generation == requestGeneration
  }

  private enum Backend: Equatable {
    case speechAnalyzer
    case legacy
  }

  private enum VoiceFollowingError: Error {
    case localTranscriptionUnavailable
    case microphoneUnavailable
  }
}

private final class LegacyAudioBufferSink: @unchecked Sendable {
  private let lock = NSLock()
  private var request: SFSpeechAudioBufferRecognitionRequest?

  func setRequest(_ request: SFSpeechAudioBufferRecognitionRequest?) {
    lock.lock()
    self.request = request
    lock.unlock()
  }

  func append(_ buffer: AVReadOnlyAudioPCMBuffer) {
    lock.lock()
    let activeRequest = request
    lock.unlock()
    activeRequest?.append(AVAudioPCMBuffer(copying: buffer))
  }
}
