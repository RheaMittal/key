import SwiftUI

struct LyricsPane: View {
  var song: Song
  @Bindable var playback: PlaybackState

  @ScaledMetric(relativeTo: .body) private var baseLyricSize = 24.0
  @ScaledMetric(relativeTo: .body) private var chordLabelSize = 16.0

  var body: some View {
    ScrollViewReader { scrollProxy in
      ScrollView {
        LazyVStack(alignment: .leading, spacing: 18) {
          ForEach(Array(song.sections.enumerated()), id: \.offset) { sectionIndex, section in
            VStack(alignment: .leading, spacing: 12) {
              Text(section.name)
                .font(.system(size: 15, weight: .bold, design: .rounded))
                .textCase(.uppercase)
                .tracking(1.1)
                .foregroundStyle(Color(hex: "#6E6A80"))
                .padding(.horizontal, 4)

              ForEach(Array(section.lines.enumerated()), id: \.offset) { lineIndex, line in
                let isCurrent = playback.currentSectionIndex == sectionIndex
                  && playback.currentLineIndex == lineIndex
                lyricRow(line, isCurrent: isCurrent)
                  .id("\(sectionIndex)-\(lineIndex)")
              }
            }
          }
        }
        .padding(.horizontal, 18)
        .padding(.vertical, 20)
        .frame(maxWidth: .infinity, alignment: .leading)
      }
      .scrollBounceBehavior(.basedOnSize, axes: .vertical)
      .onChange(of: playback.currentLineID) { _, lineID in
        withAnimation(.easeInOut(duration: 0.32)) {
          scrollProxy.scrollTo(lineID, anchor: .center)
        }
      }
      .onAppear {
        scrollProxy.scrollTo(playback.currentLineID, anchor: .center)
      }
    }
    .accessibilityLabel("Lyrics")
  }

  private func lyricRow(_ line: SongLine, isCurrent: Bool) -> some View {
    VStack(alignment: .leading, spacing: 5) {
      GeometryReader { geometry in
        ZStack(alignment: .topLeading) {
          ForEach(Array(line.chords.enumerated()), id: \.offset) { _, timedChord in
            let finalBeat = max(4, line.chords.map(\.beat).max() ?? 4)
            let progress = min(max((timedChord.beat - 1) / (finalBeat - 1), 0), 1)
            Text(timedChord.chord.symbol)
              .font(.system(size: chordLabelSize, weight: .bold, design: .rounded))
              .foregroundStyle(timedChord.chord.root.color(for: timedChord.chord.quality))
              .position(x: 18 + progress * max(0, geometry.size.width - 36), y: 12)
          }
        }
      }
      .frame(height: 24)

      Text(line.lyric)
        .font(.system(size: baseLyricSize + (isCurrent ? 5 : 0), weight: isCurrent ? .semibold : .regular, design: .rounded))
        .foregroundStyle(Color(hex: "#1D1B2A"))
        .fixedSize(horizontal: false, vertical: true)
        .frame(maxWidth: .infinity, alignment: .leading)
    }
    .padding(.horizontal, 14)
    .padding(.vertical, 12)
    .background {
      RoundedRectangle(cornerRadius: 18, style: .continuous)
        .fill(isCurrent ? Color.white.opacity(0.88) : Color.white.opacity(0.38))
    }
    .overlay {
      RoundedRectangle(cornerRadius: 18, style: .continuous)
        .strokeBorder(isCurrent ? Color(hex: "#C026D3").opacity(0.28) : .clear, lineWidth: 1)
    }
    .animation(.easeInOut(duration: 0.25), value: isCurrent)
  }
}
