import AVFoundation
import SwiftUI

struct CameraCaptureOverlay: View {
  var model: CameraCaptureModel
  @Binding var isPresented: Bool
  @State private var isAccessoryAvailable = false

  var body: some View {
    GeometryReader { geometry in
      let division = geometry.reservedRegions(kind: .division).first(where: \.isActive)?.frame
      let occlusion = geometry.reservedRegions(kind: .occlusion).first(where: \.isActive)?.frame
      let framingFrame = Self.framingFrame(in: geometry.size, division: division)
      let previewFrame = model.isRecording
        ? Self.thumbnailFrame(
          in: geometry.size,
          safeAreaInsets: geometry.safeAreaInsets,
          reservedFrames: [division, occlusion].compactMap { $0 }
        )
        : framingFrame

      ZStack {
        Color.black
          .opacity(model.isRecording ? 0 : 1)
          .ignoresSafeArea()
          .allowsHitTesting(!model.isRecording)

        CameraPreviewView(session: model.session)
          .frame(width: previewFrame.width, height: previewFrame.height)
          .clipShape(RoundedRectangle(cornerRadius: model.isRecording ? 20 : 0, style: .continuous))
          .overlay {
            if model.isRecording {
              RoundedRectangle(cornerRadius: 20, style: .continuous)
                .strokeBorder(.white.opacity(0.22), lineWidth: 1)
            }
          }
          .overlay(alignment: .topLeading) {
            if model.isRecording {
              recordingBadge
                .padding(8)
            }
          }
          .shadow(color: .black.opacity(model.isRecording ? 0.28 : 0), radius: 18, y: 8)
          .position(x: previewFrame.midX, y: previewFrame.midY)
          .allowsHitTesting(false)
          .accessibilityLabel(model.isRecording ? "Live camera preview, recording" : "Live camera preview, framing")

        if model.isRecording {
          recordingControls
        } else {
          framingControls
        }
      }
      .frame(maxWidth: .infinity, maxHeight: .infinity)
      .animation(.smooth(duration: 0.45), value: model.isRecording)
      .task {
        model.prepareSession()
      }
      .onDisappear {
        model.stopSession()
      }
      .alert(
        "Camera unavailable",
        isPresented: Binding(
          get: { model.errorMessage != nil },
          set: { if !$0 { model.errorMessage = nil } }
        )
      ) {
        Button("OK", role: .cancel) { model.errorMessage = nil }
      } message: {
        Text(model.errorMessage ?? "")
      }
    }
    .sceneAccessory {
      CameraCaptureAccessory(isEnabled: $isPresented) {
        CameraCaptureAccessoryControls(
          model: model,
          isAvailable: isAccessoryAvailable
        )
      }
      .onAvailabilityChange { isAvailable in
        isAccessoryAvailable = isAvailable
      }
    }
  }

  private var framingControls: some View {
    VStack(spacing: 12) {
      HStack {
        Button("Close camera") {
          isPresented = false
        }
        .buttonStyle(.bordered)
        .tint(.white)
        Spacer()
      }

      Spacer(minLength: 12)

      if let errorMessage = model.errorMessage {
        Text(errorMessage)
          .font(.footnote)
          .foregroundStyle(.white)
          .multilineTextAlignment(.center)
      } else if !model.isSessionReady {
        ProgressView("Starting camera…")
          .tint(.white)
          .foregroundStyle(.white)
      } else if model.isPreparingRecording {
        ProgressView("Starting recording…")
          .tint(.white)
          .foregroundStyle(.white)
      } else {
        Text("Frame your shot")
          .font(.title2.weight(.semibold))
          .foregroundStyle(.white)
        Text("Your preview stays live while you play.")
          .font(.subheadline)
          .foregroundStyle(.white.opacity(0.74))

        Button("Start recording") {
          model.startRecording()
        }
        .buttonStyle(.borderedProminent)
        .tint(.red)
        .disabled(!model.isSessionReady || model.isPreparingRecording)

        if let lastRecordingURL = model.lastRecordingURL {
          ShareLink(item: lastRecordingURL) {
            Text("Share last take")
              .font(.subheadline.weight(.medium))
          }
          .tint(.white)
        }
      }
    }
    .padding(20)
    .frame(maxWidth: .infinity, maxHeight: .infinity)
  }

  private var recordingControls: some View {
    VStack {
      HStack {
        Spacer()
        Button("Close camera") {
          isPresented = false
        }
        .buttonStyle(.bordered)
      }

      Spacer()

      HStack(spacing: 12) {
        Circle()
          .fill(.red)
          .frame(width: 9, height: 9)
        Text("Recording")
          .font(.subheadline.weight(.semibold))
        Spacer(minLength: 12)
        Button("Stop recording") {
          model.stopRecording()
        }
        .buttonStyle(.borderedProminent)
        .tint(.red)
      }
      .padding(14)
      .background(.ultraThinMaterial, in: Capsule())
      .padding(.bottom, 18)
    }
    .padding(20)
    .frame(maxWidth: .infinity, maxHeight: .infinity)
  }

  private var recordingBadge: some View {
    HStack(spacing: 5) {
      Circle()
        .fill(.red)
        .frame(width: 7, height: 7)
      Text("REC")
        .font(.system(size: 11, weight: .bold, design: .rounded))
        .tracking(0.4)
    }
    .foregroundStyle(.white)
    .padding(.horizontal, 8)
    .padding(.vertical, 6)
    .background(.black.opacity(0.72), in: Capsule())
    .accessibilityElement(children: .ignore)
    .accessibilityLabel("Recording")
  }

  private static func framingFrame(in size: CGSize, division: CGRect?) -> CGRect {
    guard let division else {
      return CGRect(x: 0, y: 0, width: size.width, height: size.height * 0.52)
    }

    if division.width >= division.height {
      let height = min(size.height, max(1, division.minY))
      return CGRect(x: 0, y: 0, width: size.width, height: height)
    }

    let rightStart = min(size.width, max(0, division.maxX))
    let rightWidth = size.width - rightStart
    if rightWidth > 0 {
      return CGRect(x: rightStart, y: 0, width: rightWidth, height: size.height)
    }

    return CGRect(x: 0, y: 0, width: division.minX, height: size.height)
  }

  private static func thumbnailFrame(
    in size: CGSize,
    safeAreaInsets: EdgeInsets,
    reservedFrames: [CGRect]
  ) -> CGRect {
    let width = min(164, size.width * 0.34)
    let height = min(width * 4 / 3, size.height * 0.34)
    let leadingX = safeAreaInsets.leading + 14
    let trailingX = max(12, size.width - width - safeAreaInsets.trailing - 14)
    let topY = safeAreaInsets.top + 14
    let bottomY = max(topY, size.height - height - safeAreaInsets.bottom - 14)
    let candidates = [
      CGRect(x: trailingX, y: topY, width: width, height: height),
      CGRect(x: trailingX, y: bottomY, width: width, height: height),
      CGRect(x: leadingX, y: bottomY, width: width, height: height),
      CGRect(x: leadingX, y: topY, width: width, height: height)
    ]
    return candidates.first { candidate in
      reservedFrames.allSatisfy { !candidate.intersects($0) }
    } ?? candidates[0]
  }
}

private struct CameraPreviewView: UIViewRepresentable {
  var session: AVCaptureSession

  func makeUIView(context: Context) -> CameraPreviewHostView {
    let view = CameraPreviewHostView()
    view.previewLayer.session = session
    view.previewLayer.videoGravity = .resizeAspectFill
    return view
  }

  func updateUIView(_ uiView: CameraPreviewHostView, context: Context) {
    if uiView.previewLayer.session !== session {
      uiView.previewLayer.session = session
    }
  }
}

private final class CameraPreviewHostView: UIView {
  override class var layerClass: AnyClass {
    AVCaptureVideoPreviewLayer.self
  }

  var previewLayer: AVCaptureVideoPreviewLayer {
    layer as! AVCaptureVideoPreviewLayer
  }
}

private struct CameraCaptureAccessoryControls: View {
  var model: CameraCaptureModel
  var isAvailable: Bool

  var body: some View {
    HStack(spacing: 14) {
      Circle()
        .fill(model.isRecording ? Color.red : Color.secondary)
        .frame(width: 9, height: 9)
      Text(model.isRecording ? "REC" : "Ready")
        .font(.caption.weight(.bold))
        .accessibilityAddTraits(.isHeader)

      Button(model.isRecording ? "Stop" : model.isPreparingRecording ? "Starting…" : "Record") {
        model.toggleRecording()
      }
      .buttonStyle(.borderedProminent)
      .tint(.red)
      .disabled(!isAvailable || !model.isSessionReady || model.isPreparingRecording)
    }
    .padding(.horizontal, 14)
    .padding(.vertical, 10)
    .background(.regularMaterial, in: Capsule())
    .accessibilityElement(children: .contain)
  }
}
