import SwiftUI

struct ContentView: View {
  @State private var playback = PlaybackState()
  @State private var sessionStore = SessionStore()
  @State private var launchPhase = false
  @State private var isLaunchVisible = true

  var body: some View {
    ZStack {
      TabView {
        NavigationStack {
          LibraryView(playback: playback, sessionStore: sessionStore)
        }
        .tabItem {
          Label("Library", systemImage: "music.note.list")
        }

        NavigationStack {
          ActivityView()
        }
        .tabItem {
          Label("Activity", systemImage: "chart.bar.fill")
        }
      }
      .background {
        KeyBackground()
      }
      .tint(Color(hex: "#1D1B2A"))

      if isLaunchVisible {
        LaunchAnimationView(phase: launchPhase)
          .transition(.opacity)
          .zIndex(1)
      }
    }
    .animation(.easeOut(duration: 0.3), value: isLaunchVisible)
    .task {
      withAnimation(.easeInOut(duration: 0.65)) {
        launchPhase = true
      }
      try? await Task.sleep(for: .milliseconds(600))
      withAnimation(.easeInOut(duration: 0.6)) {
        launchPhase = false
      }
      try? await Task.sleep(for: .milliseconds(600))
      withAnimation(.easeOut(duration: 0.3)) {
        isLaunchVisible = false
      }
    }
  }
}
