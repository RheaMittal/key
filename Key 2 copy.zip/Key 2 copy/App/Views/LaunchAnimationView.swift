import SwiftUI

struct LaunchAnimationView: View {
  var phase: Bool

  private let hues: [Double] = [
    0.88, 0.94, 0.99, 0.04, 0.09, 0.15, 0.23,
    0.31, 0.42, 0.52, 0.60, 0.70, 0.78, 0.84
  ]

  var body: some View {
    ZStack {
      Color(hex: "#FBFAFE").opacity(0.42)
        .ignoresSafeArea()

      VStack(spacing: 3) {
        ZStack {
          MeshGradient(
            width: 3,
            height: 3,
            points: [
              SIMD2<Float>(0, 0), SIMD2<Float>(0.5, 0.04), SIMD2<Float>(1, 0),
              SIMD2<Float>(0.02, 0.5), SIMD2<Float>(0.5, phase ? 0.43 : 0.57), SIMD2<Float>(0.98, 0.5),
              SIMD2<Float>(0, 1), SIMD2<Float>(0.5, 0.96), SIMD2<Float>(1, 1)
            ],
            colors: [
              Color(hex: "#C026D3"), Color(hex: "#F2552C"), Color(hex: "#F28C28"),
              Color(hex: "#3B5BDB"), Color.white, Color(hex: "#E5484D"),
              Color(hex: "#0284C7"), Color(hex: "#0E9F9E"), Color(hex: "#5E9E0D")
            ],
            smoothsColors: true
          )
          .frame(width: 58, height: 58)
          .clipShape(Circle())
          .blur(radius: 15)
          .opacity(0.76)
          .hueRotation(.degrees(phase ? 12 : -5))

          GeometryReader { geometry in
            let center = CGPoint(x: geometry.size.width / 2, y: geometry.size.height / 2)
            let radius = 34.0

            ForEach(Array(hues.enumerated()), id: \.offset) { index, hue in
              let angle = (Double(index) / Double(hues.count) * 2 * .pi) - .pi / 2
              let shiftedHue = (hue + (phase ? 0.035 : 0)).truncatingRemainder(dividingBy: 1)
              Circle()
                .fill(Color(hue: shiftedHue, saturation: 0.86, brightness: 0.91))
                .frame(width: 9, height: 9)
                .shadow(color: Color(hue: shiftedHue, saturation: 0.85, brightness: 0.9).opacity(0.42), radius: 4)
                .position(
                  x: center.x + cos(angle) * radius,
                  y: center.y + sin(angle) * radius
                )
            }
          }
          .frame(width: 94, height: 94)
          .animation(.easeInOut(duration: 0.65), value: phase)
        }
        .frame(width: 94, height: 94)

        Text("Key")
          .font(.system(size: 17, weight: .semibold, design: .rounded))
          .foregroundStyle(Color(hex: "#1D1B2A"))
      }
      .compositingGroup()
    }
    .accessibilityHidden(true)
  }
}
