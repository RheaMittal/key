import SwiftUI

struct UkuleleChordDiagram: View {
  var fingering: ChordFingering?
  var tint: Color
  var isEmphasized = false

  private var baseFret: Int {
    let fretted = fingering?.frets.filter { $0 > 0 } ?? []
    guard let lowest = fretted.min(), lowest > 4 else { return 1 }
    return lowest
  }

  var body: some View {
    Canvas { context, size in
      let gridColor = isEmphasized ? Color.white.opacity(0.72) : tint.opacity(0.42)
      let markerColor = isEmphasized ? Color.white : tint
      let left: CGFloat = 19
      let right = size.width - 19
      let top: CGFloat = 20
      let bottom = size.height - 11
      let stringSpacing = (right - left) / 3
      let fretSpacing = (bottom - top) / 4

      var strings = Path()
      for stringIndex in 0..<4 {
        let x = left + CGFloat(stringIndex) * stringSpacing
        strings.move(to: CGPoint(x: x, y: top))
        strings.addLine(to: CGPoint(x: x, y: bottom))
      }
      context.stroke(strings, with: .color(gridColor), lineWidth: 1.3)

      var frets = Path()
      for fretIndex in 0...4 {
        let y = top + CGFloat(fretIndex) * fretSpacing
        frets.move(to: CGPoint(x: left, y: y))
        frets.addLine(to: CGPoint(x: right, y: y))
      }
      context.stroke(frets, with: .color(gridColor), lineWidth: 1.3)

      if baseFret == 1 {
        var nut = Path()
        nut.move(to: CGPoint(x: left, y: top))
        nut.addLine(to: CGPoint(x: right, y: top))
        context.stroke(nut, with: .color(isEmphasized ? .white : tint.opacity(0.8)), lineWidth: 4)
      } else {
        context.draw(
          Text("\(baseFret)fr")
            .font(.system(size: 9, weight: .semibold, design: .rounded))
            .foregroundColor(isEmphasized ? .white : tint),
          at: CGPoint(x: 7, y: top + fretSpacing / 2)
        )
      }

      guard let frets = fingering?.frets else { return }
      for stringIndex in 0..<min(frets.count, 4) {
        let fret = frets[stringIndex]
        let x = left + CGFloat(stringIndex) * stringSpacing
        if fret < 0 {
          context.draw(
            Text("×")
              .font(.system(size: 11, weight: .semibold, design: .rounded))
              .foregroundColor(Color(hex: "#6E6A80")),
            at: CGPoint(x: x, y: top - 8)
          )
        } else if fret == 0 {
          let marker = CGRect(x: x - 4, y: top - 13, width: 8, height: 8)
          context.stroke(Path(ellipseIn: marker), with: .color(markerColor), lineWidth: 1.5)
        } else {
          let relativeFret = fret - baseFret
          guard (0..<4).contains(relativeFret) else { continue }
          let y = top + (CGFloat(relativeFret) + 0.5) * fretSpacing
          let dot = CGRect(x: x - 6, y: y - 6, width: 12, height: 12)
          context.fill(Path(ellipseIn: dot), with: .color(markerColor))
        }
      }
    }
    .accessibilityHidden(true)
  }
}
