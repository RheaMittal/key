import SwiftUI

struct LibraryView: View {
  var playback: PlaybackState
  var sessionStore: SessionStore
  @State private var searchText = ""

  private var visibleSongs: [Song] {
    let songs = SongCatalog.bundledSongs.sorted { lhs, rhs in
      if lhs.title == "drivers license" { return true }
      if rhs.title == "drivers license" { return false }
      return lhs.title.localizedCaseInsensitiveCompare(rhs.title) == .orderedAscending
    }
    guard !searchText.isEmpty else { return songs }
    return songs.filter {
      $0.title.localizedCaseInsensitiveContains(searchText)
        || $0.artist.localizedCaseInsensitiveContains(searchText)
    }
  }

  var body: some View {
    List(visibleSongs) { song in
      NavigationLink(value: song) {
        VStack(alignment: .leading, spacing: 4) {
          Text(song.title)
            .font(.system(size: 18, weight: .semibold, design: .rounded))
            .foregroundStyle(Color(hex: "#1D1B2A"))
          Text(song.artist)
            .font(.subheadline)
            .foregroundStyle(Color(hex: "#6E6A80"))
        }
        .padding(.vertical, 8)
      }
      .listRowBackground(Color.white.opacity(0.48))
    }
    .listStyle(.plain)
    .scrollContentBackground(.hidden)
    .background(.clear)
    .navigationTitle("Library")
    .searchable(text: $searchText, prompt: "Songs or artists")
    .navigationDestination(for: Song.self) { song in
      SongView(song: song, playback: playback, sessionStore: sessionStore)
    }
  }
}
