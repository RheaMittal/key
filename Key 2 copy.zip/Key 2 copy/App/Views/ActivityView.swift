import SwiftUI
import SwiftData

struct ActivityView: View {
  @Query(sort: \SessionRecord.startedAt, order: .reverse) private var allSessions: [SessionRecord]

  private var sessions: [SessionRecord] {
    allSessions.filter { $0.endedAt != nil }
  }

  var body: some View {
    Group {
      if sessions.isEmpty {
        ContentUnavailableView(
          "No sessions yet",
          systemImage: "chart.bar.fill",
          description: Text("Songs you play will show up here.")
        )
      } else {
        List(sessions) { session in
          VStack(alignment: .leading, spacing: 7) {
            HStack(alignment: .firstTextBaseline) {
              Text(session.songsPlayed.first?.title ?? "Practice session")
                .font(.system(size: 17, weight: .semibold, design: .rounded))
                .foregroundStyle(Color(hex: "#1D1B2A"))
              Spacer()
              Text(Self.durationText(session.duration))
                .font(.subheadline.weight(.medium))
                .foregroundStyle(Color(hex: "#6E6A80"))
            }
            Text(session.startedAt.formatted(date: .abbreviated, time: .shortened))
              .font(.subheadline)
              .foregroundStyle(Color(hex: "#6E6A80"))
            Text(session.songsPlayed.map(\.title).joined(separator: ", "))
              .font(.caption)
              .foregroundStyle(Color(hex: "#6E6A80"))
            if let note = session.note, !note.isEmpty {
              Text(note)
                .font(.subheadline)
                .foregroundStyle(Color(hex: "#1D1B2A"))
                .lineLimit(2)
            }
            Text("Difficulty \(session.difficultyRating)/5 · \(session.songsPlayed.reduce(0) { $0 + $1.sectionReplayCounts.values.reduce(0, +) }) section replays")
              .font(.caption)
              .foregroundStyle(Color(hex: "#6E6A80"))
          }
          .padding(.vertical, 8)
          .listRowBackground(Color.white.opacity(0.48))
        }
        .listStyle(.plain)
        .scrollContentBackground(.hidden)
      }
    }
    .navigationTitle("Activity")
    .background(Color.clear)
  }

  private static func durationText(_ duration: TimeInterval) -> String {
    let seconds = max(0, Int(duration))
    let minutes = seconds / 60
    let remainingSeconds = seconds % 60
    return minutes > 0 ? "\(minutes)m \(remainingSeconds)s" : "\(remainingSeconds)s"
  }
}
