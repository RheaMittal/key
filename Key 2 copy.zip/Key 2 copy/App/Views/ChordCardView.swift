import SwiftUI

struct ChordCardView: View {
  var chord: Chord
  var isCurrent: Bool
  var diagramHeight: CGFloat

  private var chordColor: Color {
    chord.root.color(for: chord.quality)
  }

  var body: some View {
    VStack(spacing: isCurrent ? 8 : 4) {
      Text(chord.symbol)
        .font(.system(size: isCurrent ? 48 : 28, weight: .bold, design: .rounded))
        .foregroundStyle(isCurrent ? .white : chordColor)
        .contentTransition(.numericText())

      UkuleleChordDiagram(
        fingering: ChordLibrary().fingering(for: chord),
        tint: chordColor,
        isEmphasized: isCurrent
      )
      .frame(height: diagramHeight)
    }
    .padding(.horizontal, isCurrent ? 16 : 11)
    .padding(.vertical, isCurrent ? 16 : 12)
    .frame(maxWidth: .infinity, maxHeight: .infinity)
    .background {
      RoundedRectangle(cornerRadius: 22, style: .continuous)
        .fill(isCurrent ? chordColor : Color.white.opacity(0.62))
        .overlay {
          if !isCurrent {
            RoundedRectangle(cornerRadius: 22, style: .continuous)
              .fill(chordColor.opacity(0.1))
          }
        }
    }
    .overlay {
      RoundedRectangle(cornerRadius: 22, style: .continuous)
        .strokeBorder(chordColor.opacity(isCurrent ? 0.15 : 0.18), lineWidth: 1)
    }
    .shadow(color: chordColor.opacity(isCurrent ? 0.2 : 0.04), radius: isCurrent ? 18 : 6, y: isCurrent ? 10 : 3)
    .animation(.easeInOut(duration: 0.28), value: isCurrent)
    .accessibilityElement(children: .combine)
    .accessibilityLabel("\(chord.symbol) ukulele chord")
  }
}
