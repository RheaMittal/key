import Foundation
import SwiftData

struct SessionSongRecord: Codable, Hashable, Identifiable {
  var id: String
  var title: String
  var artist: String
  var key: String
  var sectionReplayCounts: [String: Int]
}

@Model
final class SessionRecord {
  @Attribute(.unique) var id: UUID
  var startedAt: Date
  var endedAt: Date?
  var songsPlayedData: Data
  var note: String?
  var difficultyRating: Int

  var songsPlayed: [SessionSongRecord] {
    get { (try? JSONDecoder().decode([SessionSongRecord].self, from: songsPlayedData)) ?? [] }
    set { songsPlayedData = (try? JSONEncoder().encode(newValue)) ?? Data() }
  }

  var duration: TimeInterval {
    (endedAt ?? Date()).timeIntervalSince(startedAt)
  }

  init(
    id: UUID = UUID(),
    startedAt: Date = Date(),
    endedAt: Date? = nil,
    songsPlayed: [SessionSongRecord] = [],
    note: String? = nil,
    difficultyRating: Int = 3
  ) {
    self.id = id
    self.startedAt = startedAt
    self.endedAt = endedAt
    self.songsPlayedData = (try? JSONEncoder().encode(songsPlayed)) ?? Data()
    self.note = note
    self.difficultyRating = difficultyRating
  }
}
