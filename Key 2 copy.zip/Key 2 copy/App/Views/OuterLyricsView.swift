import SwiftUI

struct OuterLyricsView: View {
  var song: Song
  @Bindable var playback: PlaybackState

  @ScaledMetric(relativeTo: .largeTitle) private var currentLineSize = 42.0
  @ScaledMetric(relativeTo: .title2) private var nextLineSize = 26.0

  private var songLines: [(id: String, section: String, line: SongLine)] {
    song.sections.enumerated().flatMap { sectionIndex, section in
      section.lines.enumerated().map { lineIndex, line in
        ("\(sectionIndex)-\(lineIndex)", section.name, line)
      }
    }
  }

  private var visibleLines: [(id: String, section: String, line: SongLine)] {
    guard let index = songLines.firstIndex(where: { $0.id == playback.currentLineID }) else {
      return Array(songLines.prefix(5))
    }
    return Array(songLines.dropFirst(index).prefix(6))
  }

  var body: some View {
    VStack(alignment: .leading, spacing: 20) {
      VStack(alignment: .leading, spacing: 4) {
        Text(song.title)
          .font(.system(size: 24, weight: .bold, design: .rounded))
          .foregroundStyle(Color(hex: "#1D1B2A"))
        Text(song.artist)
          .font(.subheadline)
          .foregroundStyle(Color(hex: "#6E6A80"))
      }
      .padding(.horizontal, 24)
      .padding(.top, 22)

      ScrollViewReader { scrollProxy in
        ScrollView {
          LazyVStack(alignment: .leading, spacing: 22) {
            ForEach(Array(visibleLines.enumerated()), id: \.element.id) { index, item in
              VStack(alignment: .leading, spacing: 8) {
                if index == 0 {
                  Text(item.section.uppercased())
                    .font(.system(size: 13, weight: .bold, design: .rounded))
                    .tracking(1.2)
                    .foregroundStyle(Color(hex: "#6E6A80"))
                }
                Text(item.line.lyric)
                  .font(.system(size: index == 0 ? currentLineSize : nextLineSize, weight: index == 0 ? .bold : .medium, design: .rounded))
                  .foregroundStyle(Color(hex: "#1D1B2A").opacity(index == 0 ? 1 : 0.72))
                  .padding(index == 0 ? 16 : 0)
                  .frame(maxWidth: .infinity, alignment: .leading)
                  .background {
                    if index == 0 {
                      RoundedRectangle(cornerRadius: 20, style: .continuous)
                        .fill(Color.white.opacity(0.9))
                    }
                  }
              }
              .id(item.id)
            }
          }
          .padding(.horizontal, 24)
          .padding(.bottom, 32)
          .frame(maxWidth: .infinity, alignment: .leading)
        }
        .scrollBounceBehavior(.basedOnSize, axes: .vertical)
        .onChange(of: playback.currentLineID) { _, lineID in
          withAnimation(.easeInOut(duration: 0.32)) {
            scrollProxy.scrollTo(lineID, anchor: .top)
          }
        }
      }
    }
    .frame(maxWidth: .infinity, maxHeight: .infinity, alignment: .topLeading)
    .accessibilityLabel("Lyrics for friends")
  }
}
