import SwiftUI
import SwiftData

struct SongView: View {
  var song: Song
  @Bindable var playback: PlaybackState
  var sessionStore: SessionStore
  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @State private var voiceFollowing = VoiceFollowingService()
  @State private var cameraCapture = CameraCaptureModel()
  @State private var isCameraCaptureVisible = false
  @State private var isDebugPresented = false
  @State private var isSessionFinishPresented = false
  @State private var shouldDismissAfterNotes = false
  @State private var resumePlaybackAfterCancel = false
  @State private var resumeVoiceFollowingAfterCancel = false

  var body: some View {
    GeometryReader { geometry in
      let isPortrait = geometry.size.height >= geometry.size.width
      let mode = playback.displayMode(isPortrait: isPortrait)

      Group {
        switch mode {
        case .outerLyrics:
          OuterLyricsView(song: playback.song ?? song, playback: playback)
        case .jam:
          jamArrangement(song: playback.song ?? song)
        case .learn:
          learnArrangement(song: playback.song ?? song)
        }
      }
      .frame(maxWidth: .infinity, maxHeight: .infinity)
      .background {
        KeyBackground()
      }
      .onHingeChange { _, context in
        guard let hinge = context.hinge else { return }
        switch hinge.status {
        case .closed:
          playback.updateHingePose(.closed)
        case .partiallyOpen:
          playback.updateHingePose(.partiallyOpen)
        case .fullyOpen:
          playback.updateHingePose(.fullyOpen)
        default:
          break
        }
      }
      .onAppear {
        let startsNewSession = sessionStore.startSong(song, modelContext: modelContext)
        playback.load(song, forceReset: startsNewSession)
      }
      .onChange(of: playback.replayCounts) { _, counts in
        sessionStore.updateReplays(for: playback.song ?? song, counts: counts)
      }
      .toolbar(mode == .outerLyrics || isCameraCaptureVisible ? .hidden : .visible, for: .navigationBar)
      .toolbar(mode == .outerLyrics || isCameraCaptureVisible ? .hidden : .visible, for: .tabBar)
      .toolbar {
        if mode != .outerLyrics && !isCameraCaptureVisible {
          ToolbarItem(placement: .principal) {
            Text(song.title)
              .font(.headline)
              .lineLimit(1)
              .onTapGesture(count: 5) {
                isDebugPresented = true
              }
              .accessibilityAction(named: Text("Open layout debug options")) {
                isDebugPresented = true
              }
          }

          ToolbarItem(placement: .topBarPinnedTrailing) {
            Button {
              resumePlaybackAfterCancel = playback.isPlaying
              resumeVoiceFollowingAfterCancel = voiceFollowing.isEnabled
              Task { await voiceFollowing.stop() }
              playback.stop()
              isSessionFinishPresented = true
            } label: {
              Label("Done", systemImage: "checkmark")
            }
          }

          ToolbarItemGroup(placement: .topBarTrailing) {
            Button {
              playback.togglePlayback()
            } label: {
              Label(
                playback.isPlaying ? "Pause" : "Play",
                systemImage: playback.isPlaying ? "pause.fill" : "play.fill"
              )
            }

            Button {
              playback.jumpToPreviousSection()
            } label: {
              Label("Previous section", systemImage: "backward.fill")
            }

            Button {
              playback.jumpToNextSection()
            } label: {
              Label("Next section", systemImage: "forward.fill")
            }
          }
          .visibilityPriority(.high)

          ToolbarItemGroup(placement: .topBarTrailing) {
            voiceFollowingToggle
            tempoMenu
            transposeMenu

            Button {
              playback.applyEasyKey()
            } label: {
              Label("Easy key", systemImage: "wand.and.sparkles")
            }
          }

          if mode == .jam {
            ToolbarItem(placement: .topBarTrailing) {
              Button("Camera") {
                isCameraCaptureVisible = true
              }
            }
          }
        }
      }
      .sheet(isPresented: $isDebugPresented) {
        LayoutDebugSheet(playback: playback)
          .presentationDetents([.height(190)])
      }
      .sheet(isPresented: $isSessionFinishPresented, onDismiss: {
        if shouldDismissAfterNotes {
          dismiss()
        } else {
          resumeAfterSessionCancel()
        }
      }) {
        SessionFinishSheet(
          sessionStore: sessionStore,
          song: playback.song ?? song,
          replayCounts: playback.replayCounts,
          onCancel: {
            resumeAfterSessionCancel()
          },
          onSaved: {
            playback.stop()
            shouldDismissAfterNotes = true
            isSessionFinishPresented = false
          }
        )
      }
      .alert(
        "Voice following unavailable",
        isPresented: Binding(
          get: { voiceFollowing.statusMessage != nil },
          set: { isPresented in
            if !isPresented { voiceFollowing.dismissStatusMessage() }
          }
        )
      ) {
        Button("OK", role: .cancel) { voiceFollowing.dismissStatusMessage() }
      } message: {
        Text(voiceFollowing.statusMessage ?? "")
      }
      .onDisappear {
        Task { await voiceFollowing.stop() }
        cameraCapture.stopSession()
      }
    }
    .navigationBarTitleDisplayMode(.inline)
    .overlay {
      if isCameraCaptureVisible {
        CameraCaptureOverlay(model: cameraCapture, isPresented: $isCameraCaptureVisible)
          .transition(.opacity)
          .zIndex(2)
      }
    }
    .animation(.smooth(duration: 0.25), value: isCameraCaptureVisible)
  }

  @ViewBuilder
  private func learnArrangement(song: Song) -> some View {
    ArrangementView {
      LyricsPane(song: song, playback: playback)
    } secondary: {
      ChordCarouselPane(song: song, playback: playback)
    }
    .arrangementViewStyle(.split)
  }

  @ViewBuilder
  private func jamArrangement(song: Song) -> some View {
    ArrangementView {
      ChordCarouselPane(song: song, playback: playback)
    } secondary: {
      LyricsPane(song: song, playback: playback)
    }
    .arrangementViewStyle(.split)
  }

  private var tempoMenu: some View {
    Menu {
      Picker(
        "Tempo",
        selection: Binding(
          get: { playback.tempoMultiplier },
          set: { playback.setTempoMultiplier($0) }
        )
      ) {
        Text("60%") .tag(0.6)
        Text("80%") .tag(0.8)
        Text("100%") .tag(1.0)
        Text("120%") .tag(1.2)
      }
    } label: {
      Label("Tempo", systemImage: "metronome")
    }
  }

  private var voiceFollowingToggle: some View {
    Toggle(
      isOn: Binding(
        get: { voiceFollowing.isEnabled },
        set: { isEnabled in
          Task { await voiceFollowing.setEnabled(isEnabled, playback: playback) }
        }
      )
    ) {
      Label {
        Text(voiceFollowing.controlTitle)
          .lineLimit(1)
      } icon: {
        Image(systemName: "waveform")
          .symbolEffect(.pulse, isActive: voiceFollowing.isListening)
      }
    }
    .toggleStyle(.button)
    .tint(voiceFollowing.isEnabled ? Color(hex: "#0E9F6E") : Color(hex: "#1D1B2A"))
    .accessibilityLabel("Follow my voice")
    .accessibilityValue(voiceFollowing.latestTranscript ?? (voiceFollowing.isListening ? "Listening for lyrics" : "Off"))
    .accessibilityHint("Match spoken words to the current or next lyric lines. When speech is recognized, the last words heard are shown here.")
  }

  private func resumeAfterSessionCancel() {
    if resumePlaybackAfterCancel && sessionStore.activeSession != nil {
      playback.start()
    }
    if resumeVoiceFollowingAfterCancel {
      Task { await voiceFollowing.setEnabled(true, playback: playback) }
    }
    resumePlaybackAfterCancel = false
    resumeVoiceFollowingAfterCancel = false
  }

  private var transposeMenu: some View {
    Menu {
      Button("Transpose down", systemImage: "arrow.down") {
        playback.transpose(by: -1)
      }
      Button("Transpose up", systemImage: "arrow.up") {
        playback.transpose(by: 1)
      }
      Button("Reset transpose", systemImage: "arrow.uturn.backward") {
        playback.resetTranspose()
      }
    } label: {
      Label("Transpose", systemImage: "arrow.up.arrow.down")
    }
  }
}

private struct LayoutDebugSheet: View {
  @Bindable var playback: PlaybackState

  var body: some View {
    NavigationStack {
      Form {
        Picker("Display mode", selection: $playback.modeOverride) {
          ForEach(DisplayModeOverride.allCases) { mode in
            Text(mode.rawValue).tag(mode)
          }
        }
      }
      .navigationTitle("Layout debug")
      .navigationBarTitleDisplayMode(.inline)
    }
  }
}
