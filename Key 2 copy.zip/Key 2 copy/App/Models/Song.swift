struct Song: Codable, Hashable, Identifiable {
  var title: String
  var artist: String
  var key: ChordRoot
  var bpm: Int
  var sections: [SongSection]

  var id: String {
    "\(artist)-\(title)"
  }

  func shifted(by semitones: Int) -> Song {
    Song(
      title: title,
      artist: artist,
      key: key.shifted(by: semitones),
      bpm: bpm,
      sections: sections.map { $0.shifted(by: semitones) }
    )
  }

  var uniqueChords: [Chord] {
    var seen: Set<Chord> = []
    return sections.flatMap(\.lines)
      .flatMap(\.chords)
      .map(\.chord)
      .filter { seen.insert($0).inserted }
  }
}
