enum SongCatalog {
  static let bundledSongs: [Song] = {
    guard let song = try? SongLoader.loadBundledSong(named: "drivers-license") else { return [] }
    return [song]
  }()
}
