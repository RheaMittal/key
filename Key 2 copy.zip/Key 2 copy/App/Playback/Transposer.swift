enum Transposer {
  private static let baseDifficultyByQuality: [ChordQuality: Double] = [
    .major: 1,
    .minor: 1.2,
    .sixth: 1.1,
    .dominant7: 1.3,
    .major7: 2,
    .add9: 1.7,
    .add11: 1.8,
    .alternate: 1.8
  ]

  private static let hardRootPenalties: [ChordRoot: Double] = [
    .aSharp: 4, // Bb
    .b: 4,
    .dSharp: 4, // Eb
    .e: 4,
    .cSharp: 4, // Db
    .gSharp: 4  // Ab
  ]

  private static let hardChordPenalties: [Chord: Double] = [
    Chord(root: .cSharp, quality: .minor): 3,
    Chord(root: .fSharp, quality: .minor): 3
  ]

  static func shift(_ song: Song, by semitones: Int) -> Song {
    song.shifted(by: semitones)
  }

  static func easyKeySuggestion(for song: Song) -> EasyKeySuggestion {
    (0..<12)
      .map { semitones in
        let shiftedSong = song.shifted(by: semitones)
        return EasyKeySuggestion(
          semitones: semitones,
          score: score(shiftedSong),
          song: shiftedSong
        )
      }
      .min { lhs, rhs in
        if lhs.score == rhs.score {
          return absoluteShift(lhs.semitones) < absoluteShift(rhs.semitones)
        }
        return lhs.score < rhs.score
      } ?? EasyKeySuggestion(semitones: 0, score: score(song), song: song)
  }

  private static func score(_ song: Song) -> Double {
    song.uniqueChords.reduce(0) { total, chord in
      total + difficulty(for: chord)
    }
  }

  private static func difficulty(for chord: Chord) -> Double {
    baseDifficultyByQuality[chord.quality, default: 1]
      + hardRootPenalties[chord.root, default: 0]
      + hardChordPenalties[chord, default: 0]
  }

  private static func absoluteShift(_ semitones: Int) -> Int {
    min(semitones, 12 - semitones)
  }

}
