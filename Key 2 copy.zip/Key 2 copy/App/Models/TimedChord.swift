struct TimedChord: Codable, Hashable, Identifiable {
  var beat: Double
  var chord: Chord

  var id: String {
    "\(beat)-\(chord.symbol)"
  }

  func shifted(by semitones: Int) -> TimedChord {
    TimedChord(beat: beat, chord: chord.shifted(by: semitones))
  }
}
