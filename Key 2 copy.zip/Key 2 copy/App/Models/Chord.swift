import Foundation

struct Chord: Codable, Hashable, Identifiable {
  var root: ChordRoot
  var quality: ChordQuality

  var id: String { symbol }

  enum CodingKeys: String, CodingKey {
    case root
    case quality
  }

  init(root: ChordRoot, quality: ChordQuality = .major) {
    self.root = root
    self.quality = quality
  }

  init(from decoder: Decoder) throws {
    if let value = try? decoder.singleValueContainer().decode(String.self) {
      guard let chord = Chord(symbol: value) else {
        throw DecodingError.dataCorrupted(
          DecodingError.Context(codingPath: decoder.codingPath, debugDescription: "Unknown chord: \(value)")
        )
      }
      self = chord
      return
    }

    let container = try decoder.container(keyedBy: CodingKeys.self)
    root = try container.decode(ChordRoot.self, forKey: .root)
    quality = try container.decode(ChordQuality.self, forKey: .quality)
  }

  init?(symbol: String) {
    let trimmed = symbol.trimmingCharacters(in: .whitespacesAndNewlines)
    let roots = ["C#", "Db", "D#", "Eb", "F#", "Gb", "G#", "Ab", "A#", "Bb", "C", "D", "E", "F", "G", "A", "B"]

    guard let rootText = roots.first(where: { trimmed.hasPrefix($0) }),
          let parsedRoot = ChordRoot(rootText) else {
      return nil
    }

    let suffix = String(trimmed.dropFirst(rootText.count)).lowercased()
    let parsedQuality: ChordQuality
    switch suffix {
    case "":
      parsedQuality = .major
    case "m", "min", "minor":
      parsedQuality = .minor
    case "7":
      parsedQuality = .dominant7
    case "6":
      parsedQuality = .sixth
    case "maj7":
      parsedQuality = .major7
    case "add9":
      parsedQuality = .add9
    case "add11":
      parsedQuality = .add11
    case "*":
      parsedQuality = .alternate
    default:
      return nil
    }

    root = parsedRoot
    quality = parsedQuality
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.singleValueContainer()
    try container.encode(symbol)
  }

  var symbol: String {
    root.displayName + quality.suffix
  }

  func shifted(by semitones: Int) -> Chord {
    Chord(root: root.shifted(by: semitones), quality: quality)
  }
}
