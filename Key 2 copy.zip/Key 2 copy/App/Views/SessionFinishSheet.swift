import SwiftUI
import SwiftData

struct SessionFinishSheet: View {
  var sessionStore: SessionStore
  var song: Song
  var replayCounts: [String: Int]
  var onCancel: () -> Void
  var onSaved: () -> Void

  @Environment(\.dismiss) private var dismiss
  @Environment(\.modelContext) private var modelContext
  @State private var finishedSession: SessionRecord?
  @State private var isShowingNotes = false

  var body: some View {
    NavigationStack {
      VStack(spacing: 18) {
        Image(systemName: "checkmark")
          .font(.system(size: 25, weight: .bold))
          .foregroundStyle(Color(hex: "#1D1B2A"))
          .frame(width: 56, height: 56)
          .background(Color.white.opacity(0.8), in: Circle())

        VStack(spacing: 6) {
          Text("Session length")
            .font(.headline)
            .foregroundStyle(Color(hex: "#6E6A80"))
          Text(Self.durationText(sessionStore.activeSession?.duration ?? 0))
            .font(.system(size: 34, weight: .bold, design: .rounded))
            .foregroundStyle(Color(hex: "#1D1B2A"))
        }

        Button("Continue to notes", systemImage: "note.text") {
          if finishedSession == nil {
            finishedSession = sessionStore.finishSession(
              song: song,
              replayCounts: replayCounts,
              modelContext: modelContext
            )
          }
          isShowingNotes = finishedSession != nil
        }
        .buttonStyle(.borderedProminent)
        .tint(Color(hex: "#1D1B2A"))
      }
      .frame(maxWidth: .infinity, maxHeight: .infinity)
      .padding(24)
      .background(KeyBackground())
      .navigationTitle("Session complete")
      .navigationBarTitleDisplayMode(.inline)
      .toolbar {
        if finishedSession == nil {
          ToolbarItem(placement: .cancellationAction) {
            Button("Keep playing") {
              onCancel()
              dismiss()
            }
          }
        }
      }
      .navigationDestination(isPresented: $isShowingNotes) {
        if let finishedSession {
          SessionNotesView(session: finishedSession, onSave: onSaved)
        }
      }
    }
    .presentationDetents([.medium, .large])
    .interactiveDismissDisabled(finishedSession != nil)
  }

  private static func durationText(_ duration: TimeInterval) -> String {
    let seconds = max(0, Int(duration))
    let hours = seconds / 3600
    let minutes = (seconds % 3600) / 60
    let remainingSeconds = seconds % 60
    if hours > 0 { return "\(hours)h \(minutes)m" }
    if minutes > 0 { return "\(minutes)m \(remainingSeconds)s" }
    return "\(remainingSeconds)s"
  }
}

private struct SessionNotesView: View {
  var session: SessionRecord
  var onSave: () -> Void

  @Environment(\.modelContext) private var modelContext
  @State private var note: String
  @State private var difficultyRating: Int

  init(session: SessionRecord, onSave: @escaping () -> Void) {
    self.session = session
    self.onSave = onSave
    _note = State(initialValue: session.note ?? "")
    _difficultyRating = State(initialValue: session.difficultyRating)
  }

  private var replayRows: [(id: String, title: String, section: String, count: Int)] {
    session.songsPlayed.flatMap { song in
      song.sectionReplayCounts
        .filter { $0.value > 0 }
        .sorted { $0.key.localizedCaseInsensitiveCompare($1.key) == .orderedAscending }
        .map { section, count in
          ("\(song.id)-\(section)", song.title, section, count)
        }
    }
  }

  var body: some View {
    Form {
      Section("Session") {
        LabeledContent("Date", value: session.startedAt.formatted(date: .complete, time: .shortened))
        LabeledContent("Duration", value: Self.durationText(session.duration))
      }

      Section("Songs played") {
        ForEach(session.songsPlayed) { song in
          VStack(alignment: .leading, spacing: 3) {
            Text(song.title)
              .font(.body.weight(.semibold))
            Text("\(song.artist) · Key \(song.key)")
              .font(.subheadline)
              .foregroundStyle(.secondary)
          }
        }
      }

      Section("Sections replayed") {
        if replayRows.isEmpty {
          Text("No section replays")
            .foregroundStyle(.secondary)
        } else {
          ForEach(replayRows, id: \.id) { replay in
            HStack {
              VStack(alignment: .leading, spacing: 2) {
                Text(replay.section)
                if session.songsPlayed.count > 1 {
                  Text(replay.title).font(.caption).foregroundStyle(.secondary)
                }
              }
              Spacer()
              Text("×\(replay.count)")
                .font(.body.weight(.semibold))
                .foregroundStyle(.secondary)
            }
          }
        }
      }

      Section("Optional note") {
        TextField("Add a note about this session", text: $note, axis: .vertical)
          .lineLimit(2...5)
      }

      Section("Difficulty · 1–5") {
        Picker("Rating", selection: $difficultyRating) {
          Text("1 · Easy").tag(1)
          Text("2 · Manageable").tag(2)
          Text("3 · Moderate").tag(3)
          Text("4 · Challenging").tag(4)
          Text("5 · Very hard").tag(5)
        }
        .pickerStyle(.menu)
      }
    }
    .navigationTitle("Session notes")
    .navigationBarTitleDisplayMode(.inline)
    .toolbar {
      ToolbarItem(placement: .confirmationAction) {
        Button("Save") {
          let cleanedNote = note.trimmingCharacters(in: .whitespacesAndNewlines)
          session.note = cleanedNote.isEmpty ? nil : cleanedNote
          session.difficultyRating = difficultyRating
          try? modelContext.save()
          onSave()
        }
      }
    }
  }

  private static func durationText(_ duration: TimeInterval) -> String {
    let seconds = max(0, Int(duration))
    let hours = seconds / 3600
    let minutes = (seconds % 3600) / 60
    let remainingSeconds = seconds % 60
    if hours > 0 { return "\(hours)h \(minutes)m \(remainingSeconds)s" }
    if minutes > 0 { return "\(minutes)m \(remainingSeconds)s" }
    return "\(remainingSeconds)s"
  }
}
