import Foundation
import Observation
import SwiftData

@MainActor @Observable
final class SessionStore {
  private(set) var activeSession: SessionRecord?

  @discardableResult
  func startSong(_ song: Song, modelContext: ModelContext) -> Bool {
    let startedNewSession = activeSession == nil
    if activeSession == nil {
      let session = SessionRecord()
      modelContext.insert(session)
      activeSession = session
    }

    if let activeSession, !activeSession.songsPlayed.contains(where: { $0.id == song.id }) {
      var songs = activeSession.songsPlayed
      songs.append(
        SessionSongRecord(
          id: song.id,
          title: song.title,
          artist: song.artist,
          key: song.key.displayName,
          sectionReplayCounts: [:]
        )
      )
      activeSession.songsPlayed = songs
    }
    return startedNewSession
  }

  func updateReplays(for song: Song, counts: [String: Int]) {
    guard let activeSession,
          let songIndex = activeSession.songsPlayed.firstIndex(where: { $0.id == song.id }) else { return }
    var songs = activeSession.songsPlayed
    songs[songIndex].sectionReplayCounts = counts
    songs[songIndex].key = song.key.displayName
    activeSession.songsPlayed = songs
  }

  func finishSession(
    song: Song,
    replayCounts: [String: Int],
    modelContext: ModelContext
  ) -> SessionRecord? {
    guard let activeSession else { return nil }
    updateReplays(for: song, counts: replayCounts)
    activeSession.endedAt = Date()
    try? modelContext.save()
    self.activeSession = nil
    return activeSession
  }
}
