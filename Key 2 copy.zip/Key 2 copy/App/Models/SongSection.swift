struct SongSection: Codable, Hashable, Identifiable {
  var name: String
  var strumPattern: String
  var technique: String?
  var lines: [SongLine]

  var id: String { name }

  func shifted(by semitones: Int) -> SongSection {
    SongSection(
      name: name,
      strumPattern: strumPattern,
      technique: technique,
      lines: lines.map { $0.shifted(by: semitones) }
    )
  }
}
