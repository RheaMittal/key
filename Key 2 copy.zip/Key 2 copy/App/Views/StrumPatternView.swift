import SwiftUI

struct StrumPatternView: View {
  var sectionName: String
  var pattern: String
  var technique: String?
  var currentBeat: Double
  var isPlaying: Bool
  var accent: Color
  var compact = false

  private var tokens: [String] {
    pattern
      .replacingOccurrences(of: "–", with: "-")
      .replacingOccurrences(of: "—", with: "-")
      .split(whereSeparator: \.isWhitespace)
      .map(String.init)
  }

  private var isDirectionPattern: Bool {
    !tokens.isEmpty && tokens.allSatisfy { ["D", "U", "-", "·"].contains($0.uppercased()) }
  }

  private var isSinglePluck: Bool {
    pattern.localizedCaseInsensitiveContains("single pluck")
  }

  private var isHold: Bool {
    pattern.localizedCaseInsensitiveContains("hold") || technique?.localizedCaseInsensitiveContains("let each chord ring") == true
  }

  private var steps: [StrumStep] {
    if isDirectionPattern {
      return tokens.enumerated().map { index, token in
        let symbol = token.uppercased()
        let label: String
        let spoken: String
        switch symbol {
        case "D": label = "arrow.down"; spoken = "down strum"
        case "U": label = "arrow.up"; spoken = "up strum"
        default: label = "minus"; spoken = "rest"
        }
        return StrumStep(index: index, symbol: label, spoken: spoken, count: countLabel(index, total: tokens.count))
      }
    }

    let count = isSinglePluck || isHold ? 4 : 8
    let symbol = isHold ? "minus" : "circle.fill"
    let spoken = isHold ? "let chord ring" : "pluck"
    return (0..<count).map { index in
      StrumStep(index: index, symbol: symbol, spoken: spoken, count: countLabel(index, total: count))
    }
  }

  private var currentStepIndex: Int {
    guard !steps.isEmpty else { return 0 }
    let tick = max(0, Int(((currentBeat - 1) * 2).rounded(.down)))
    let position = steps.count == 4 ? tick / 2 : tick
    return position % steps.count
  }

  private var patternSummary: String {
    if isDirectionPattern { return tokens.joined(separator: " ") }
    if isHold { return "LET RING" }
    if technique?.localizedCaseInsensitiveContains("pluck") == true { return "PLUCK · LET RING" }
    return "FOLLOW CHORD FIGURE"
  }

  var body: some View {
    VStack(alignment: .leading, spacing: compact ? 7 : 11) {
      HStack(alignment: .firstTextBaseline, spacing: 8) {
        Text("Strum · \(sectionName)")
          .font(.system(size: compact ? 14 : 16, weight: .semibold, design: .rounded))
          .foregroundStyle(Color(hex: "#292638"))
          .lineLimit(1)

        Spacer(minLength: 4)

        Text(patternSummary)
          .font(.system(size: compact ? 9 : 10, weight: .medium, design: .monospaced))
          .tracking(0.5)
          .foregroundStyle(Color(hex: "#77738A"))
          .lineLimit(1)
      }

      HStack(spacing: compact ? 3 : 6) {
        ForEach(steps) { step in
          let isCurrent = step.index == currentStepIndex
          VStack(spacing: compact ? 3 : 6) {
            Group {
              if step.symbol == "arrow.down" || step.symbol == "arrow.up" {
                Image(systemName: step.symbol)
                  .font(.system(size: compact ? 19 : 23, weight: .bold))
              } else if step.symbol == "circle.fill" {
                Circle()
                  .fill(isCurrent ? accent : Color(hex: "#B7B3C4"))
                  .frame(width: compact ? 5 : 7, height: compact ? 5 : 7)
              } else {
                Capsule()
                  .fill(isCurrent ? accent : Color(hex: "#B7B3C4"))
                  .frame(width: compact ? 10 : 14, height: 2)
              }
            }
            .frame(height: compact ? 21 : 25)

            Text(step.count)
              .font(.system(size: compact ? 10 : 11, weight: isCurrent ? .semibold : .regular, design: .rounded))
              .foregroundStyle(isCurrent ? Color(hex: "#5C5870") : Color(hex: "#A19DB0"))
          }
          .frame(maxWidth: .infinity)
          .padding(.vertical, compact ? 4 : 7)
          .background {
            if isCurrent {
              RoundedRectangle(cornerRadius: 12, style: .continuous)
                .fill(accent.opacity(0.13))
            }
          }
          .scaleEffect(isCurrent && isPlaying ? 1.04 : 1)
          .animation(.easeInOut(duration: 0.16), value: isCurrent)
          .accessibilityElement(children: .ignore)
          .accessibilityLabel("Beat \(step.count), \(step.spoken)\(isCurrent ? ", current" : "")")
        }
      }
    }
    .padding(.horizontal, compact ? 13 : 18)
    .padding(.vertical, compact ? 9 : 15)
    .background {
      RoundedRectangle(cornerRadius: 22, style: .continuous)
        .fill(.white.opacity(0.84))
        .shadow(color: Color(hex: "#5B5080").opacity(0.07), radius: 16, y: 7)
    }
    .overlay {
      RoundedRectangle(cornerRadius: 22, style: .continuous)
        .strokeBorder(.white.opacity(0.86), lineWidth: 1)
    }
    .accessibilityElement(children: .contain)
  }

  private func countLabel(_ index: Int, total: Int) -> String {
    if total == 8 {
      return index.isMultiple(of: 2) ? "\(index / 2 + 1)" : "&"
    }
    return "\(index + 1)"
  }
}

private struct StrumStep: Identifiable {
  var index: Int
  var symbol: String
  var spoken: String
  var count: String

  var id: Int { index }
}
