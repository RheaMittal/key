import Foundation

enum SongLoaderError: Error, LocalizedError {
  case missingResource(String)

  var errorDescription: String? {
    switch self {
    case .missingResource(let name):
      "Missing bundled song resource: \(name).json"
    }
  }
}
