enum ChordQuality: String, CaseIterable, Codable, Hashable {
  case major
  case minor
  case dominant7 = "7"
  case sixth = "6"
  case major7
  case add9
  case add11
  case alternate = "*"

  init(from decoder: Decoder) throws {
    let container = try decoder.singleValueContainer()
    let value = try container.decode(String.self)

    switch value.lowercased() {
    case "major", "", "maj":
      self = .major
    case "minor", "m", "min":
      self = .minor
    case "7", "dominant7", "dominant":
      self = .dominant7
    case "6", "sixth":
      self = .sixth
    case "maj7", "major7":
      self = .major7
    case "add9":
      self = .add9
    case "add11":
      self = .add11
    case "*", "alternate":
      self = .alternate
    default:
      throw DecodingError.dataCorruptedError(
        in: container,
        debugDescription: "Unknown chord quality: \(value)"
      )
    }
  }

  var suffix: String {
    switch self {
    case .major: ""
    case .minor: "m"
    case .dominant7: "7"
    case .sixth: "6"
    case .major7: "maj7"
    case .add9: "add9"
    case .add11: "add11"
    case .alternate: "*"
    }
  }
}
