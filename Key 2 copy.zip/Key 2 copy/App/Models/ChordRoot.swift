import SwiftUI

enum ChordRoot: Int, CaseIterable, Codable, Hashable {
  case c = 0
  case cSharp = 1
  case d = 2
  case dSharp = 3
  case e = 4
  case f = 5
  case fSharp = 6
  case g = 7
  case gSharp = 8
  case a = 9
  case aSharp = 10
  case b = 11

  init(from decoder: Decoder) throws {
    let container = try decoder.singleValueContainer()
    let value = try container.decode(String.self)
    guard let root = ChordRoot(value) else {
      throw DecodingError.dataCorruptedError(
        in: container,
        debugDescription: "Unknown chord root: \(value)"
      )
    }
    self = root
  }

  init?(_ text: String) {
    switch text.trimmingCharacters(in: .whitespacesAndNewlines) {
    case "C": self = .c
    case "C#", "Db": self = .cSharp
    case "D": self = .d
    case "D#", "Eb": self = .dSharp
    case "E", "Fb": self = .e
    case "F", "E#": self = .f
    case "F#", "Gb": self = .fSharp
    case "G": self = .g
    case "G#", "Ab": self = .gSharp
    case "A": self = .a
    case "A#", "Bb": self = .aSharp
    case "B", "Cb": self = .b
    default: return nil
    }
  }

  func encode(to encoder: Encoder) throws {
    var container = encoder.singleValueContainer()
    try container.encode(displayName)
  }

  var displayName: String {
    switch self {
    case .c: "C"
    case .cSharp: "C#"
    case .d: "D"
    case .dSharp: "Eb"
    case .e: "E"
    case .f: "F"
    case .fSharp: "F#"
    case .g: "G"
    case .gSharp: "Ab"
    case .a: "A"
    case .aSharp: "Bb"
    case .b: "B"
    }
  }

  var colorHex: String {
    switch self {
    case .c: "#E5484D"
    case .cSharp: "#F2552C"
    case .d: "#F28C28"
    case .dSharp: "#C99A06"
    case .e: "#5E9E0D"
    case .f: "#0E9F6E"
    case .fSharp: "#0E9F9E"
    case .g: "#0284C7"
    case .gSharp: "#3B5BDB"
    case .a: "#7C3AED"
    case .aSharp: "#C026D3"
    case .b: "#DB2777"
    }
  }

  func shifted(by semitones: Int) -> ChordRoot {
    let count = ChordRoot.allCases.count
    let value = (rawValue + semitones % count + count) % count
    return ChordRoot(rawValue: value) ?? self
  }

  func color(for quality: ChordQuality) -> Color {
    let base = Color(hex: colorHex)
    return quality == .minor ? base.mix(with: .black, by: 0.22) : base
  }
}
