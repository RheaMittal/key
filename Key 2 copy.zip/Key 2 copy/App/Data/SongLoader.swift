import Foundation

enum SongLoader {
  static func loadBundledSong(named name: String, bundle: Bundle = .main) throws -> Song {
    guard let url = bundle.url(forResource: name, withExtension: "json") else {
      throw SongLoaderError.missingResource(name)
    }

    let data = try Data(contentsOf: url)
    let decoder = JSONDecoder()
    decoder.keyDecodingStrategy = .convertFromSnakeCase
    return try decoder.decode(Song.self, from: data)
  }
}
