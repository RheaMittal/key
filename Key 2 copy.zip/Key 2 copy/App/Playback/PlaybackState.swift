import Foundation
import Observation

enum SongDisplayMode: Hashable {
  case learn
  case jam
  case outerLyrics
}

enum DisplayModeOverride: String, CaseIterable, Identifiable {
  case automatic = "Automatic"
  case learn = "Learn"
  case jam = "Jam"

  var id: String { rawValue }
}

enum HingePose {
  case closed
  case partiallyOpen
  case fullyOpen
}

@MainActor @Observable
final class PlaybackState {
  private(set) var sourceSong: Song?
  private(set) var currentSectionIndex = 0
  private(set) var currentLineIndex = 0
  private(set) var currentBeat = 1.0
  private(set) var isPlaying = false
  private(set) var isVoiceFollowingActive = false
  private(set) var replayCounts: [String: Int] = [:]
  var tempoMultiplier = 1.0
  var transposeSemitones = 0
  var hingePose: HingePose?
  var modeOverride = DisplayModeOverride.automatic

  @ObservationIgnored private var timer: Timer?

  var song: Song? {
    sourceSong?.shifted(by: transposeSemitones)
  }

  var currentSection: SongSection? {
    guard let sections = song?.sections, sections.indices.contains(currentSectionIndex) else {
      return nil
    }
    return sections[currentSectionIndex]
  }

  var currentLine: SongLine? {
    guard let lines = currentSection?.lines, lines.indices.contains(currentLineIndex) else {
      return nil
    }
    return lines[currentLineIndex]
  }

  var currentChord: Chord? {
    guard let chords = currentLine?.chords, !chords.isEmpty else { return nil }
    return chords.last(where: { $0.beat <= Double(currentBeat) })?.chord ?? chords[0].chord
  }

  var currentChordCarouselIndex: Int? {
    guard let currentChord, let chords = song?.uniqueChords else { return nil }
    return chords.firstIndex(of: currentChord)
  }

  var currentLineID: String {
    "\(currentSectionIndex)-\(currentLineIndex)"
  }

  var currentSectionStartLineIndex: Int {
    guard let song else { return 0 }
    return song.sections.prefix(currentSectionIndex).reduce(0) { $0 + $1.lines.count }
  }

  func displayMode(isPortrait: Bool) -> SongDisplayMode {
    if hingePose == .closed {
      return .outerLyrics
    }

    switch modeOverride {
    case .automatic:
      if hingePose == .partiallyOpen && isPortrait { return .jam }
      return .learn
    case .learn:
      return .learn
    case .jam:
      return .jam
    }
  }

  func load(_ song: Song, forceReset: Bool = false) {
    guard forceReset || sourceSong?.id != song.id else { return }
    stop()
    sourceSong = song
    currentSectionIndex = 0
    currentLineIndex = 0
    currentBeat = 1
    transposeSemitones = 0
    replayCounts = [:]
  }

  func togglePlayback() {
    isPlaying ? stop() : start()
  }

  func start() {
    guard song != nil, !isPlaying else { return }
    isPlaying = true
    scheduleTimer()
  }

  func stop() {
    isPlaying = false
    timer?.invalidate()
    timer = nil
  }

  func setTempoMultiplier(_ value: Double) {
    tempoMultiplier = value
    if isPlaying { scheduleTimer() }
  }

  func transpose(by semitones: Int) {
    transposeSemitones = (transposeSemitones + semitones % 12 + 12) % 12
  }

  func resetTranspose() {
    transposeSemitones = 0
  }

  func applyEasyKey() {
    guard let song else { return }
    let suggestion = Transposer.easyKeySuggestion(for: song)
    transpose(by: suggestion.semitones)
  }

  func jumpToPreviousSection() {
    jump(to: currentSectionIndex - 1)
  }

  func jumpToNextSection() {
    jump(to: currentSectionIndex + 1)
  }

  func updateHingePose(_ pose: HingePose) {
    hingePose = pose
  }

  func setVoiceFollowingActive(_ isActive: Bool) {
    isVoiceFollowingActive = isActive
  }

  func correctForward(to position: SongLinePosition) {
    guard let song,
          song.sections.indices.contains(position.sectionIndex),
          song.sections[position.sectionIndex].lines.indices.contains(position.lineIndex),
          let currentOffset = lineOffset(sectionIndex: currentSectionIndex, lineIndex: currentLineIndex, in: song),
          let targetOffset = lineOffset(sectionIndex: position.sectionIndex, lineIndex: position.lineIndex, in: song),
          targetOffset > currentOffset else {
      return
    }

    currentSectionIndex = position.sectionIndex
    currentLineIndex = position.lineIndex
    currentBeat = 1
  }

  private func jump(to targetIndex: Int) {
    guard let sections = song?.sections, sections.indices.contains(targetIndex) else { return }
    if targetIndex < currentSectionIndex {
      let sectionName = sections[targetIndex].name
      replayCounts[sectionName, default: 0] += 1
    }
    currentSectionIndex = targetIndex
    currentLineIndex = 0
    currentBeat = 1
  }

  private func scheduleTimer() {
    timer?.invalidate()
    guard let baseBPM = sourceSong?.bpm else { return }
    let interval = 30.0 / (Double(baseBPM) * tempoMultiplier)
    timer = Timer(timeInterval: interval, repeats: true) { [weak self] _ in
      Task { @MainActor [weak self] in
        self?.advanceSubdivision()
      }
    }
    if let timer {
      RunLoop.main.add(timer, forMode: .common)
    }
  }

  private func advanceSubdivision() {
    guard isPlaying, let line = currentLine else {
      stop()
      return
    }

    let finalChordBeat = line.chords.map(\.beat).max() ?? 1
    let lineDuration = max(4, Int(ceil(finalChordBeat)))
    if currentBeat >= Double(lineDuration) + 0.5 {
      if isVoiceFollowingActive {
        currentBeat = Double(lineDuration) + 0.5
        return
      }

      if let lines = currentSection?.lines, currentLineIndex + 1 < lines.count {
        currentLineIndex += 1
        currentBeat = 1
      } else if let sections = song?.sections, currentSectionIndex + 1 < sections.count {
        currentSectionIndex += 1
        currentLineIndex = 0
        currentBeat = 1
      } else {
        stop()
      }
    } else {
      currentBeat += 0.5
    }
  }

  private func lineOffset(sectionIndex: Int, lineIndex: Int, in song: Song) -> Int? {
    guard song.sections.indices.contains(sectionIndex),
          song.sections[sectionIndex].lines.indices.contains(lineIndex) else {
      return nil
    }

    return song.sections.prefix(sectionIndex).reduce(0) { $0 + $1.lines.count } + lineIndex
  }
}
