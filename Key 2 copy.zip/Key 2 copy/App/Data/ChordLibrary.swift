struct ChordLibrary {
  private var fingeringsByChord: [Chord: ChordFingering]

  init(fingerings: [ChordFingering] = ChordLibrary.defaultFingerings) {
    fingeringsByChord = Dictionary(uniqueKeysWithValues: fingerings.map { ($0.chord, $0) })
  }

  func fingering(for chord: Chord) -> ChordFingering? {
    fingeringsByChord[chord]
  }

  static var defaultFingerings: [ChordFingering] {
    majorFingerings + minorFingerings + dominant7Fingerings + sixthFingerings + extendedFingerings
  }

  private static var majorFingerings: [ChordFingering] {
    [
      ChordFingering("C", "0003"),
      ChordFingering("C#", "1114"),
      ChordFingering("D", "2220"),
      ChordFingering("Eb", "0331"),
      ChordFingering("E", "4442"),
      ChordFingering("F", "2010"),
      ChordFingering("F#", "3121"),
      ChordFingering("G", "0232"),
      ChordFingering("Ab", "5343"),
      ChordFingering("A", "2100"),
      ChordFingering("Bb", "3211"),
      ChordFingering("B", "4322")
    ]
  }

  private static var minorFingerings: [ChordFingering] {
    [
      ChordFingering("Cm", "0333"),
      ChordFingering("C#m", "110x"),
      ChordFingering("Dm", "2210"),
      ChordFingering("Ebm", "3321"),
      ChordFingering("Em", "0432"),
      ChordFingering("Fm", "1013"),
      ChordFingering("F#m", "2120"),
      ChordFingering("Gm", "0231"),
      ChordFingering("Abm", "1342"),
      ChordFingering("Am", "2000"),
      ChordFingering("Bbm", "3111"),
      ChordFingering("Bm", "4222")
    ]
  }

  private static var dominant7Fingerings: [ChordFingering] {
    [
      ChordFingering("C7", "0001"),
      ChordFingering("C#7", "1112"),
      ChordFingering("D7", "2223"),
      ChordFingering("Eb7", "3334"),
      ChordFingering("E7", "1202"),
      ChordFingering("F7", "2313"),
      ChordFingering("F#7", "3424"),
      ChordFingering("G7", "0212"),
      ChordFingering("Ab7", "1323"),
      ChordFingering("A7", "0100"),
      ChordFingering("Bb7", "1211"),
      ChordFingering("B7", "2322")
    ]
  }

  private static var sixthFingerings: [ChordFingering] {
    [
      ChordFingering("C6", "0000"),
      ChordFingering("C#6", "1111"),
      ChordFingering("D6", "2222"),
      ChordFingering("Eb6", "3333"),
      ChordFingering("E6", "4444"),
      ChordFingering("F6", "5555"),
      ChordFingering("F#6", "6666"),
      ChordFingering("G6", "7777"),
      ChordFingering("Ab6", "8888"),
      ChordFingering("A6", "9999"),
      ChordFingering("Bb6", [10, 10, 10, 10]),
      ChordFingering("B6", [11, 11, 11, 11])
    ]
  }

  private static var extendedFingerings: [ChordFingering] {
    transposedFingerings(from: .d, quality: .major7, template: [2, 2, 2, 4])
      + transposedFingerings(from: .a, quality: .add9, template: [2, 1, 0, 2])
      + transposedFingerings(from: .e, quality: .add11, template: [4, 4, 4, 0])
      + transposedFingerings(from: .d, quality: .alternate, template: [2, 2, 2, 5])
  }

  private static func transposedFingerings(
    from baseRoot: ChordRoot,
    quality: ChordQuality,
    template: [Int]
  ) -> [ChordFingering] {
    ChordRoot.allCases.map { root in
      let clockwiseShift = (root.rawValue - baseRoot.rawValue + 12) % 12
      let shift = clockwiseShift > 6 ? clockwiseShift - 12 : clockwiseShift
      let frets = template.map { fret in
        guard fret >= 0 else { return -1 }
        let shifted = fret + shift
        return shifted < 0 ? shifted + 12 : shifted
      }
      return ChordFingering(chord: Chord(root: root, quality: quality), frets: frets)
    }
  }
}
